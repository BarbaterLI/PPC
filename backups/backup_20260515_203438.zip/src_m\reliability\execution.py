"""Execution result and metrics types

Provides ExecutionResult for wrapping execution outcomes and ExecutionMetrics for tracking performance.
"""

import time
from dataclasses import dataclass, field
from typing import Any, List, Optional, Dict, Generic, TypeVar
from enum import Enum
from pathlib import Path

T = TypeVar("T")


@dataclass
class ExecutionMetrics:
    """Execution metrics"""

    start_time: float = 0.0
    end_time: float = 0.0
    duration: float = 0.0
    memory_peak_kb: int = 0
    bytes_processed: int = 0
    request_count: int = 0
    retry_count: int = 0
    extra: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        """Convert to dictionary"""
        return {
            "duration": self.duration,
            "memory_peak_kb": self.memory_peak_kb,
            "bytes_processed": self.bytes_processed,
            "request_count": self.request_count,
            "retry_count": self.retry_count,
            **self.extra,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "ExecutionMetrics":
        """Create from dictionary"""
        return cls(
            duration=data.get("duration", 0.0),
            memory_peak_kb=data.get("memory_peak_kb", 0),
            bytes_processed=data.get("bytes_processed", 0),
            request_count=data.get("request_count", 0),
            retry_count=data.get("retry_count", 0),
            extra={k: v for k, v in data.items() if k not in (
                "duration", "memory_peak_kb", "bytes_processed", "request_count", "retry_count"
            )},
        )


@dataclass
class ExecutionResult(Generic[T]):
    """Execution result wrapper"""

    success: bool = True
    partial: bool = False
    data: Optional[T] = None
    error: Optional[str] = None
    error_code: Optional[str] = None
    errors: List[str] = field(default_factory=list)
    metrics: Optional[ExecutionMetrics] = None

    @classmethod
    def success(cls, data: Optional[T] = None, metrics: Optional[ExecutionMetrics] = None) -> "ExecutionResult[T]":
        """Create successful result"""
        return cls(success=True, partial=False, data=data, metrics=metrics)

    @classmethod
    def failure(cls, error: str = "", error_code: Optional[str] = None,
                metrics: Optional[ExecutionMetrics] = None) -> "ExecutionResult[T]":
        """Create failed result"""
        return cls(success=False, partial=False, error=error, error_code=error_code, metrics=metrics)

    @classmethod
    def partial(cls, data: Optional[T] = None, errors: Optional[List[str]] = None,
                metrics: Optional[ExecutionMetrics] = None) -> "ExecutionResult[T]":
        """Create partial success result"""
        return cls(success=True, partial=True, data=data, errors=errors or [], metrics=metrics)

    @classmethod
    def error(cls, error: str = "", error_code: Optional[str] = None,
              metrics: Optional[ExecutionMetrics] = None) -> "ExecutionResult[T]":
        """Create error result (alias for failure)"""
        return cls.failure(error=error, error_code=error_code, metrics=metrics)

    def is_success(self) -> bool:
        """Check if successful"""
        return self.success

    def is_failure(self) -> bool:
        """Check if failed"""
        return not self.success

    def is_partial(self) -> bool:
        """Check if partial success"""
        return self.partial

    def to_dict(self) -> dict:
        """Convert to dictionary"""
        result = {
            "success": self.success,
            "partial": self.partial,
            "data": self.data,
            "error": self.error,
            "error_code": self.error_code,
            "errors": self.errors,
        }
        if self.metrics:
            result["metrics"] = self.metrics.to_dict()
        return result


@dataclass
class TaskResult:
    """Single task execution result"""

    task_id: str = ""
    success: bool = False
    output_path: Optional[Path] = None
    duration: float = 0.0
    output_size: int = 0
    attempts: int = 0
    error: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "task_id": self.task_id,
            "success": self.success,
            "output_path": str(self.output_path) if self.output_path else None,
            "duration": self.duration,
            "output_size": self.output_size,
            "attempts": self.attempts,
            "error": self.error,
        }


@dataclass
class BatchResult:
    """Batch execution result"""

    total: int = 0
    succeeded: int = 0
    failed: int = 0
    duration: float = 0.0
    results: List[TaskResult] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "total": self.total,
            "succeeded": self.succeeded,
            "failed": self.failed,
            "duration": self.duration,
            "results": [r.to_dict() for r in self.results],
        }


@dataclass
class RetryPolicy:
    """Retry policy configuration"""

    max_retries: int = 3
    base_delay: float = 1.0
    max_delay: float = 60.0
    exponential_base: float = 2.0
    jitter: float = 0.1
    retryable_exceptions: tuple = (Exception,)
    retry_condition: Optional[Any] = None

    def get_delay(self, attempt: int) -> float:
        """Calculate delay for given attempt"""
        delay = self.base_delay * (self.exponential_base ** attempt)
        delay = min(delay, self.max_delay)
        import random
        jitter_range = delay * self.jitter
        return delay + random.uniform(-jitter_range, jitter_range)

    def should_retry(self, attempt: int, error: Exception) -> bool:
        """Check if should retry"""
        if attempt >= self.max_retries:
            return False
        if type(error) in self.retryable_exceptions:
            return True
        for exc_type in self.retryable_exceptions:
            if isinstance(error, exc_type):
                return True
        return False

    def to_dict(self) -> dict:
        """Convert to dictionary"""
        return {
            "max_retries": self.max_retries,
            "base_delay": self.base_delay,
            "max_delay": self.max_delay,
            "exponential_base": self.exponential_base,
            "jitter": self.jitter,
        }


class RetryEventType(str, Enum):
    """Retry event types"""
    RETRY = "retry"
    GIVE_UP = "give_up"
    CIRCUIT_BREAKER_TRIGGERED = "circuit_breaker"
    RECOVERY = "recovery"


@dataclass
class RetryEvent:
    """Retry event data"""

    event_type: RetryEventType = RetryEventType.RETRY
    attempt: int = 0
    max_retries: int = 3
    error: Optional[str] = None
    delay: float = 0.0
    timestamp: float = 0.0

    def __post_init__(self):
        if self.timestamp == 0.0:
            self.timestamp = time.time()

    def to_dict(self) -> dict:
        return {
            "event_type": self.event_type.value if isinstance(self.event_type, RetryEventType) else str(self.event_type),
            "attempt": self.attempt,
            "max_retries": self.max_retries,
            "error": self.error,
            "delay": self.delay,
            "timestamp": self.timestamp,
        }


def create_network_retry_policy(
    max_retries: int = 5,
    base_delay: float = 2.0,
    max_delay: float = 120.0,
    exponential_base: float = 2.0,
    jitter: float = 0.1,
) -> RetryPolicy:
    """Create retry policy for network operations"""
    return RetryPolicy(
        max_retries=max_retries,
        base_delay=base_delay,
        max_delay=max_delay,
        exponential_base=exponential_base,
        jitter=jitter,
    )


def create_tts_retry_policy(
    max_retries: int = 3,
    base_delay: float = 2.0,
    max_delay: float = 30.0,
    exponential_base: float = 2.0,
    jitter: float = 0.1,
) -> RetryPolicy:
    """Create retry policy for TTS operations"""
    return RetryPolicy(
        max_retries=max_retries,
        base_delay=base_delay,
        max_delay=max_delay,
        exponential_base=exponential_base,
        jitter=jitter,
    )


def create_tts_circuit_breaker(
    name: str = "tts",
    failure_threshold: int = 5,
    timeout_seconds: float = 60.0,
    success_threshold: int = 3,
    half_open_max_calls: int = 3,
    window_seconds: float = 60.0,
) -> "CircuitBreaker":
    """Create circuit breaker for TTS operations"""
    from .circuit import CircuitBreaker, CircuitBreakerConfig

    config = CircuitBreakerConfig(
        failure_threshold=failure_threshold,
        timeout=timeout_seconds,
        success_threshold=success_threshold,
        half_open_max_calls=half_open_max_calls,
        sliding_window_size=int(window_seconds),
    )
    return CircuitBreaker(name=name, config=config)


def classify_exception(error: Exception) -> str:
    """Classify an exception into a category string"""
    error_type = type(error).__name__
    error_msg = str(error).lower()

    if "network" in error_msg or "connection" in error_msg or "timeout" in error_msg:
        return "network"
    if "auth" in error_msg or "permission" in error_msg:
        return "auth"
    if "rate" in error_msg or "limit" in error_msg:
        return "rate_limit"
    if "quota" in error_msg:
        return "quota"
    if "parse" in error_msg or "json" in error_msg:
        return "parse"
    return "unknown"
