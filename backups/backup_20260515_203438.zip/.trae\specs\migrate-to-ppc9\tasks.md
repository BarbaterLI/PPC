# Tasks

- [ ] Task 1: 备份项目并打包 fanqie 扩展
  - [ ] SubTask 1.1: 创建项目完整备份为 `backup_YYYYMMDD_HHMMSS.zip`
  - [ ] SubTask 1.2: 将 `src_m/extensions/fanqie/` 打包为 `fanqie_downloader.ppc9ext.zip`（含 manifest.yml）

- [ ] Task 2: 清理项目结构
  - [ ] SubTask 2.1: 删除 `.bak` 文件（`config.py.bak`、`manager.py.bak`）

- [ ] Task 3: 入口文件迁移
  - [ ] SubTask 3.1: 重命名 `ppc8.py` → `ppc9.py`，更新内部版本号和引用
  - [ ] SubTask 3.2: 更新 `ppc9.py` 中的 `sys.argv` 前缀为 `ppc9`

- [ ] Task 4: 核心模块版本和名称迁移
  - [ ] SubTask 4.1: `src_m/core/__init__.py` - `__version__` → `9.0.0`，`PPC8Error` → `PPC9Error`，保留 `PPC8Error` 别名
  - [ ] SubTask 4.2: `src_m/core/exceptions.py` - 所有异常类名 `PPC8*` → `PPC9*`，保留旧名别名
  - [ ] SubTask 4.3: `src_m/core/errors.py` - 更新 ppc8/ppc9 引用

- [ ] Task 5: 配置模块迁移
  - [ ] SubTask 5.1: `src_m/config/schema.py` - `PPC8Config` → `PPC9Config`，`version` 默认值 → `"9.0.0"`，保留 `PPC8Config = PPC9Config` 别名，`PPC7Config = PPC9Config`
  - [ ] SubTask 5.2: `src_m/config/manager.py` - `CONFIG_VERSION` → `"9.0.0"`，`APP_NAME` → `"PPC9"`，logger 名称更新
  - [ ] SubTask 5.3: `src_m/config/presets.py` - 版本号 → `"9.0.0"`，`COMMENTED_YAML_TEMPLATE` 中所有 `PPC8` → `PPC9`、`ppc8` → `ppc9`、版本号更新
  - [ ] SubTask 5.4: `src_m/config/migration.py` - 新增 `migrate_v8_to_v9` 方法，更新 `VERSION_MAPPING`
  - [ ] SubTask 5.5: `src_m/config/__init__.py` - 更新导出名

- [ ] Task 6: CLI 模块迁移
  - [ ] SubTask 6.1: `src_m/cli/typer_app.py` - `name="ppc9"`，help 文本更新，`sys.argv` 前缀 → `ppc9`，导入路径 `from ppc9 import __version__`
  - [ ] SubTask 6.2: `src_m/cli/ui.py` - logger 名 → `ppc9`，导入路径更新，banner 中 `PPC8` → `PPC9`
  - [ ] SubTask 6.3: `src_m/cli/output.py` - 导入路径 `from ppc9 import __version__`，所有 `ppc8`/`PPC8` 引用 → `ppc9`/`PPC9`，`BrandAssets.LOGO_ASCII` 更新为 PPC9，logger 名更新
  - [ ] SubTask 6.4: `src_m/cli/commands/` 下所有命令文件 - 更新 `ppc8` → `ppc9` 引用（示例文本、帮助信息等）
  - [ ] SubTask 6.5: `src_m/cli/simple_progress.py` - 如有 ppc8 引用则更新

- [ ] Task 7: 扩展模块迁移
  - [ ] SubTask 7.1: `src_m/extensions/base.py` - 注释中 `PPC8` → `PPC9`
  - [ ] SubTask 7.2: `src_m/extensions/loader.py` - 模块名前缀 `ppc8_ext_` → `ppc9_ext_`
  - [ ] SubTask 7.3: `src_m/extensions/package.py` - `.ppc8ext.zip` → `.ppc9ext.zip`，`min_ppc8_version` → `min_ppc9_version`，`import ppc8` → `import ppc9`，模板中引用更新
  - [ ] SubTask 7.4: `src_m/extensions/__init__.py` - 注释更新
  - [ ] SubTask 7.5: `src_m/extensions/fanqie/extension.py` - 注释中 `PPC8` → `PPC9`
  - [ ] SubTask 7.6: `src_m/extensions/fanqie/downloader.py` - ppc8 引用更新
  - [ ] SubTask 7.7: `src_m/extensions/examples/priority_lb.py` - 如有引用则更新

- [ ] Task 8: 兼容层迁移
  - [ ] SubTask 8.1: `src_m/compat.py` - 新增 `PPC8Compat` 类（PPC8→PPC9 命令映射），更新 `PPC5Compat` 中的提示信息，`ppc5_main` 中提示使用 `ppc9`

- [ ] Task 9: 其他模块迁移
  - [ ] SubTask 9.1: `src_m/legacy/ppc2_legacy.py` - 更新注释中的 PPC8 引用
  - [ ] SubTask 9.2: `src_m/engines/*` - 更新 ppc8/PPC8 引用
  - [ ] SubTask 9.3: `src_m/executors/*` - 更新 ppc8/PPC8 引用
  - [ ] SubTask 9.4: `src_m/distributed/*` - 更新 ppc8/PPC8 引用
  - [ ] SubTask 9.5: `src_m/analysis/*` - 更新 ppc8/PPC8 引用
  - [ ] SubTask 9.6: `src_m/infrastructure/*` - 更新 ppc8/PPC8 引用
  - [ ] SubTask 9.7: `src_m/webhook/service.py` - 更新 ppc8/PPC8 引用
  - [ ] SubTask 9.8: `src_m/scheduler/*` - 更新 ppc8/PPC8 引用
  - [ ] SubTask 9.9: `src_m/pool/*`、`src_m/profiler/*`、`src_m/reliability/*`、`src_m/text/*`、`src_m/timeout/*`、`src_m/tracing/*`、`src_m/cache/*`、`src_m/logging/*`、`src_m/events/*`、`src_m/audio/*` - 检查并更新引用

- [ ] Task 10: CLI UI 优化
  - [ ] SubTask 10.1: 更新 `BrandAssets.LOGO_ASCII` 为 PPC9 的 ASCII art
  - [ ] SubTask 10.2: 优化 `CLIUI.show_banner()` 中的 banner 展示
  - [ ] SubTask 10.3: 优化 `OutputFormatter.show_welcome()` 欢迎信息
  - [ ] SubTask 10.4: 优化 `OutputFormatter.show_shortcuts()` 快捷键参考
  - [ ] SubTask 10.5: 优化 `OutputFormatter.interactive_help()` 交互式帮助标题
  - [ ] SubTask 10.6: 优化 `OutputFormatter.help_index()` 命令索引标题
  - [ ] SubTask 10.7: 优化 `OutputFormatter.config_wizard()` 配置向导标题
  - [ ] SubTask 10.8: 优化进度条动画样式（`ProgressStyles`），增加新的动画模式

- [ ] Task 11: 配置文件更新
  - [ ] SubTask 11.1: 更新 `config.yml`（fanqie 配置）中的注释
  - [ ] SubTask 11.2: 更新 `requirements.txt` 中的注释

- [ ] Task 12: 验证迁移结果
  - [ ] SubTask 12.1: 全局搜索确认无遗漏的 `ppc8`/`PPC8` 引用（排除兼容别名和注释说明）
  - [ ] SubTask 12.2: 验证 `ppc9 --version` 输出 `9.0.0`
  - [ ] SubTask 12.3: 验证 `PPC8Config` 别名仍然可用
  - [ ] SubTask 12.4: 验证 `ppc8` 命令别名仍然可用

# Task Dependencies
- [Task 1] 必须最先执行（备份）
- [Task 2] 应在 Task 1 之后执行
- [Task 3] ~ [Task 9] 可并行执行（无相互依赖）
- [Task 10] 依赖 Task 6（CLI 模块迁移完成后才能优化 UI）
- [Task 11] 可与 Task 3~9 并行
- [Task 12] 必须在所有其他任务完成后执行
