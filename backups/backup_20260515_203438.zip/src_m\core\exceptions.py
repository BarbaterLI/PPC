"""Core exception definitions.

Provides a unified exception hierarchy for the PPC8 project.
All exceptions inherit from PPC8Error and include optional
error codes and structured details.
"""

from __future__ import annotations

from typing import Any


class PPC8Error(Exception):
    """Base exception for the PPC8 project."""

    def __init__(
        self,
        message: str,
        error_code: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        self.message = message
        self.error_code = error_code
        self.details = details or {}
        super().__init__(message)

    def __str__(self) -> str:
        parts = [self.message]
        if self.error_code:
            parts.append(f"[{self.error_code}]")
        if self.details:
            parts.append(f"Details: {self.details}")
        return " ".join(parts)


class EngineError(PPC8Error):
    """Engine-related errors."""


class ExecutorError(PPC8Error):
    """Executor-related errors."""


class InitializationError(PPC8Error):
    """Initialization failures."""


class CleanupError(PPC8Error):
    """Resource cleanup failures."""


class ValidationError(PPC8Error):
    """Data or configuration validation failures."""


class ConfigurationError(PPC8Error):
    """Configuration-related errors."""


class PPCTimeoutError(PPC8Error):
    """Operation timeout errors."""


class NetworkError(PPC8Error):
    """Network communication errors."""


class FileIOError(PPC8Error):
    """File I/O operation errors."""


class TTSError(PPC8Error):
    """TTS (Text-to-Speech) related errors."""


class ChapterError(PPC8Error):
    """Chapter processing related errors."""
