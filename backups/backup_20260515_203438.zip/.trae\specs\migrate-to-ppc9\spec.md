# PPC9.0.0 迁移 Spec

## Why
项目需要从 PPC8 (v8.3.0) 全面升级到 PPC9 (v9.0.0)，统一品牌名称、版本号，优化 CLI UI 和项目结构，同时保持对旧版本的向后兼容。在迁移前需先备份项目并将 fanqie 扩展打包为独立扩展包。

## What Changes
- **备份项目**：在迁移前创建完整项目备份（zip）
- **打包 fanqie 扩展**：将 `src_m/extensions/fanqie/` 打包为 `.ppc9ext.zip` 扩展包格式
- **版本号升级**：所有 `8.3.0` → `9.0.0`，所有 `8.0.0` → `9.0.0`
- **品牌名称迁移**：`PPC8` → `PPC9`，`ppc8` → `ppc9`（涉及 54 个文件）
- **入口文件重命名**：`ppc8.py` → `ppc9.py`
- **CLI 命令名迁移**：`ppc8` 命令 → `ppc9` 命令
- **配置类名迁移**：`PPC8Config` → `PPC9Config`，`PPC8Error` → `PPC9Error` 等
- **扩展包格式迁移**：`.ppc8ext.zip` → `.ppc9ext.zip`，`min_ppc8_version` → `min_ppc9_version`
- **向后兼容**：保留 `ppc8` 命令别名、`PPC8Config` 别名、旧版配置迁移路径
- **CLI UI 优化**：优化 banner ASCII art（PPC9）、优化输出格式、改进进度条样式
- **结构优化**：清理 `.bak` 文件、统一 logger 名称、更新注释模板
- **配置迁移**：新增 PPC8 → PPC9 配置迁移路径

## Impact
- Affected specs: 全部模块（54 个文件包含 ppc8/PPC8 引用）
- Affected code:
  - `ppc8.py` → 重命名为 `ppc9.py`
  - `src_m/core/__init__.py` - 版本号和异常类名
  - `src_m/core/exceptions.py` - 异常类名
  - `src_m/core/errors.py` - 错误类名
  - `src_m/cli/typer_app.py` - CLI 入口
  - `src_m/cli/ui.py` - UI 类
  - `src_m/cli/output.py` - 输出格式化
  - `src_m/cli/commands/*` - 所有命令模块
  - `src_m/config/schema.py` - 配置类名
  - `src_m/config/manager.py` - 配置管理器
  - `src_m/config/presets.py` - 预设配置
  - `src_m/config/migration.py` - 迁移器
  - `src_m/compat.py` - 兼容层
  - `src_m/extensions/*` - 扩展体系
  - `src_m/legacy/ppc2_legacy.py` - 遗留代码
  - 其他所有包含 ppc8/PPC8 引用的模块

## ADDED Requirements

### Requirement: 项目备份
系统 SHALL 在迁移前创建完整项目备份，保存为 `backup_YYYYMMDD_HHMMSS.zip`。

#### Scenario: 备份成功
- **WHEN** 执行迁移操作前
- **THEN** 自动创建项目根目录的完整 zip 备份

### Requirement: fanqie 扩展打包
系统 SHALL 将 `src_m/extensions/fanqie/` 目录打包为 `.ppc9ext.zip` 扩展包格式，包含 `manifest.yml`。

#### Scenario: 打包成功
- **WHEN** 执行扩展打包操作
- **THEN** 生成 `fanqie_downloader.ppc9ext.zip`，包含 manifest.yml、extension.py、downloader.py、__init__.py

### Requirement: 版本号全面升级
系统 SHALL 将所有版本号从 `8.3.0` 升级到 `9.0.0`，默认版本必须为 `9.0.0`。

#### Scenario: 版本号更新
- **WHEN** 用户查询版本号
- **THEN** 返回 `9.0.0`

### Requirement: 品牌名称迁移
系统 SHALL 将所有 `PPC8`/`ppc8` 引用迁移为 `PPC9`/`ppc9`。

#### Scenario: 命令行入口
- **WHEN** 用户执行 `ppc9 --version`
- **THEN** 显示 `PPC9 v9.0.0`

#### Scenario: 配置类名
- **WHEN** 代码引用 `PPC9Config`
- **THEN** 正常工作，等同于原 `PPC8Config`

### Requirement: 向后兼容
系统 SHALL 保持对旧版本名称的兼容支持。

#### Scenario: ppc8 命令别名
- **WHEN** 用户执行 `ppc8` 命令
- **THEN** 自动映射到 `ppc9` 命令并正常执行，同时显示兼容性提示

#### Scenario: PPC8Config 别名
- **WHEN** 代码使用 `PPC8Config`
- **THEN** 仍然可用，映射到 `PPC9Config`

#### Scenario: 旧版配置迁移
- **WHEN** 系统检测到 PPC8 配置文件
- **THEN** 自动迁移到 PPC9 格式

### Requirement: CLI UI 优化
系统 SHALL 在现有基础上优化 CLI UI 展示。

#### Scenario: Banner 更新
- **WHEN** 显示 banner
- **THEN** 显示 PPC9 ASCII art 和新版本信息

#### Scenario: 帮助信息优化
- **WHEN** 显示命令帮助
- **THEN** 所有示例命令使用 `ppc9` 前缀

### Requirement: 扩展包格式更新
系统 SHALL 将扩展包格式从 `.ppc8ext.zip` 更新为 `.ppc9ext.zip`。

#### Scenario: 新扩展包格式
- **WHEN** 创建扩展包模板
- **THEN** 使用 `.ppc9ext.zip` 后缀和 `min_ppc9_version` 字段

#### Scenario: 旧扩展包兼容
- **WHEN** 安装 `.ppc8ext.zip` 格式的扩展包
- **THEN** 仍然可以正常安装

## MODIFIED Requirements

### Requirement: 配置版本
`PPC9Config.version` 默认值从 `"8.3.0"` 修改为 `"9.0.0"`。
`ConfigManager.CONFIG_VERSION` 从 `"8.3.0"` 修改为 `"9.0.0"`。
`ConfigManager.APP_NAME` 从 `"PPC8"` 修改为 `"PPC9"`。

### Requirement: 兼容层
`src_m/compat.py` 中的 `PPC5Compat` 新增 PPC8 → PPC9 命令映射，警告信息更新为引导使用 `ppc9`。

### Requirement: 配置迁移器
`src_m/config/migration.py` 新增 `migrate_v8_to_v9` 迁移方法，支持从 PPC8 配置自动迁移到 PPC9。

## REMOVED Requirements

### Requirement: .bak 文件
**Reason**: 清理项目结构，移除不再需要的备份文件
**Migration**: 删除 `src_m/cli/commands/config.py.bak` 和 `src_m/config/manager.py.bak`
