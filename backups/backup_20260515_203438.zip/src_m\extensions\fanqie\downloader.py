"""番茄小说下载器核心下载/安装/启动逻辑。

集成 zhongbai2333/Tomato-Novel-Downloader 到 PPC8，
提供下载器管理、版本更新、TUI/Server 启动等功能。

番茄小说下载器支持以下运行模式：
  - TUI 模式（默认）：交互式终端界面
  - Server 模式（--server）：Web UI 服务器，浏览器访问
  - CLI 更新模式（--update <book_id>）：非交互式更新已有书籍

GitHub: https://github.com/zhongbai2333/Tomato-Novel-Downloader
"""

from __future__ import annotations

import logging
import os
import platform
import shutil
import subprocess
import zipfile
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import requests
from packaging import version

logger = logging.getLogger(__name__)

GITHUB_OWNER = "zhongbai2333"
GITHUB_REPO = "Tomato-Novel-Downloader"
FANQIE_DIR_NAME = "fanqie"
EXE_NAME_WINDOWS = "TomatoNovelDownloader.exe"
EXE_NAME_LINUX = "tomato-novel-downloader"
EXE_NAME_MACOS = "tomato-novel-downloader"
DEFAULT_MIRROR = "gh.llkk.cc"


def _get_fanqie_base_dir() -> Path:
    return Path(__file__).parent.parent.parent.parent / FANQIE_DIR_NAME


def _get_exe_path() -> Path:
    base = _get_fanqie_base_dir()
    system = platform.system()
    if system == "Windows":
        return base / EXE_NAME_WINDOWS
    elif system == "Darwin":
        return base / EXE_NAME_MACOS
    else:
        return base / EXE_NAME_LINUX


def _get_version_file_path() -> Path:
    return _get_fanqie_base_dir() / ".version"


def _get_default_data_dir() -> Path:
    return _get_fanqie_base_dir()


def _get_config_path() -> Path:
    return _get_fanqie_base_dir() / "config.yml"


def is_installed() -> bool:
    exe = _get_exe_path()
    return exe.exists() and exe.stat().st_size > 0


def get_installed_version() -> Optional[str]:
    ver_file = _get_version_file_path()
    if ver_file.exists():
        try:
            return ver_file.read_text(encoding="utf-8").strip()
        except Exception:
            pass
    return None


def get_latest_release(owner: str = GITHUB_OWNER, repo: str = GITHUB_REPO) -> Dict:
    url = f"https://api.github.com/repos/{owner}/{repo}/releases/latest"
    headers = {
        "Accept": "application/vnd.github+json",
        "User-Agent": "PPC8-Fanqie-Integration",
    }
    try:
        response = requests.get(url, headers=headers, timeout=15)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"获取最新 Release 失败: {e}")


def get_releases_list(
    owner: str = GITHUB_OWNER,
    repo: str = GITHUB_REPO,
    per_page: int = 10,
    page: int = 1,
) -> List[Dict]:
    url = f"https://api.github.com/repos/{owner}/{repo}/releases"
    params = {"per_page": min(per_page, 100), "page": page}
    headers = {
        "Accept": "application/vnd.github+json",
        "User-Agent": "PPC8-Fanqie-Integration",
    }
    try:
        response = requests.get(url, headers=headers, params=params, timeout=15)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"获取 Release 列表失败: {e}")


def detect_system_info() -> Tuple[str, str]:
    system = platform.system()
    machine = platform.machine().lower()
    if hasattr(platform, "android") or "ANDROID_DATA" in os.environ:
        system = "Android"
    arch_map = {
        "x86_64": "amd64",
        "amd64": "amd64",
        "aarch64": "arm64",
        "arm64": "arm64",
        "armv7l": "arm32",
        "armv8l": "arm64",
        "i386": "386",
        "i686": "386",
    }
    architecture = arch_map.get(machine, machine)
    return system, architecture


def match_best_asset(
    assets: List[Dict],
    system: Optional[str] = None,
    arch: Optional[str] = None,
    prefer_musl: bool = False,
) -> Optional[Dict]:
    if system is None or arch is None:
        auto_system, auto_arch = detect_system_info()
        system = system or auto_system
        arch = arch or auto_arch

    candidates = []
    for asset in assets:
        name = asset["name"]
        if ("Source" in name and name.endswith(".zip")) or (
            "Source" in name and name.endswith(".tar.gz")
        ):
            continue

        if system == "Windows":
            if arch == "amd64" and "Win64" in name:
                candidates.append(("Win64", 0, asset))
            elif arch == "arm64" and "WinArm64" in name:
                candidates.append(("WinArm64", 0, asset))
        elif system == "Linux":
            if arch == "amd64":
                if "musl" in name and "amd64" in name:
                    candidates.append(("musl_amd64", 2 if prefer_musl else 1, asset))
                elif "amd64" in name and "musl" not in name:
                    candidates.append(("gnu_amd64", 0 if prefer_musl else 2, asset))
            elif arch == "arm64":
                if "musl" in name and "arm64" in name:
                    candidates.append(("musl_arm64", 2 if prefer_musl else 1, asset))
                elif "arm64" in name and "musl" not in name:
                    candidates.append(("gnu_arm64", 0 if prefer_musl else 2, asset))
        elif system in ("macOS", "Darwin"):
            if arch == "amd64" and "macOS_amd64" in name:
                candidates.append(("macOS_amd64", 0, asset))
            elif arch == "arm64" and "macOS_arm64" in name:
                candidates.append(("macOS_arm64", 0, asset))
        elif system == "Android":
            if arch == "arm64" and "Android_arm64" in name:
                candidates.append(("Android_arm64", 0, asset))
            elif arch == "arm32" and "Android_arm32" in name:
                candidates.append(("Android_arm32", 0, asset))

    if candidates:
        candidates.sort(key=lambda x: x[1], reverse=True)
        return candidates[0][2]
    return None


def convert_to_mirror_url(github_url: str, mirror: str = DEFAULT_MIRROR) -> str:
    return f"https://{mirror}/{github_url}"


def compare_versions(v1: str, v2: str) -> int:
    try:
        ver1 = version.parse(v1.lstrip("v"))
        ver2 = version.parse(v2.lstrip("v"))
        if ver1 < ver2:
            return -1
        elif ver1 > ver2:
            return 1
        else:
            return 0
    except Exception:
        if v1 < v2:
            return -1
        elif v1 > v2:
            return 1
        return 0


def download_file(
    url: str,
    output_path: str,
    timeout: int = 60,
    chunk_size: int = 8192,
    progress_callback=None,
) -> Tuple[bool, str]:
    try:
        response = requests.get(url, stream=True, timeout=timeout)
        response.raise_for_status()
        total_size = int(response.headers.get("content-length", 0))
        downloaded = 0
        with open(output_path, "wb") as f:
            for chunk in response.iter_content(chunk_size=chunk_size):
                if chunk:
                    f.write(chunk)
                    downloaded += len(chunk)
                    if progress_callback and total_size > 0:
                        progress_callback(downloaded, total_size)
        return True, url
    except requests.exceptions.RequestException as e:
        return False, str(e)


def download_with_fallback(
    url: str,
    fallback_url: str,
    output_path: str,
    timeout: int = 60,
    chunk_size: int = 8192,
    progress_callback=None,
) -> Tuple[bool, str]:
    urls_to_try = [(url, "镜像源"), (fallback_url, "官方 GitHub")]
    last_error = ""
    for try_url, source_name in urls_to_try:
        if not try_url:
            continue
        success, result = download_file(try_url, output_path, timeout, chunk_size, progress_callback)
        if success:
            return True, f"{source_name}: {try_url}"
        last_error = f"{source_name}失败: {result}"
    return False, last_error


def install_fanqie(
    use_mirror: bool = True,
    mirror: str = DEFAULT_MIRROR,
    prefer_musl: bool = False,
    progress_callback=None,
) -> Dict:
    release_info = get_latest_release()
    latest_version = release_info.get("tag_name", "unknown")
    assets = release_info.get("assets", [])

    best_asset = match_best_asset(assets, prefer_musl=prefer_musl)
    if not best_asset:
        return {
            "success": False,
            "error": "未找到适合当前系统的下载资源",
            "version": latest_version,
        }

    official_url = best_asset["browser_download_url"]
    mirror_url = convert_to_mirror_url(official_url, mirror) if use_mirror else None
    filename = best_asset["name"]

    base_dir = _get_fanqie_base_dir()
    base_dir.mkdir(parents=True, exist_ok=True)

    download_path = base_dir / filename

    primary_url = mirror_url if use_mirror else official_url
    fallback = official_url if use_mirror else None

    success, msg = download_with_fallback(
        primary_url,
        fallback or "",
        str(download_path),
        timeout=120,
        progress_callback=progress_callback,
    )

    if not success:
        return {
            "success": False,
            "error": f"下载失败: {msg}",
            "version": latest_version,
        }

    extracted = _extract_and_install(download_path, base_dir)
    if not extracted:
        return {
            "success": False,
            "error": "解压或安装失败",
            "version": latest_version,
        }

    ver_file = _get_version_file_path()
    ver_file.write_text(latest_version, encoding="utf-8")

    novels_dir = _get_fanqie_base_dir() / "novels"
    novels_dir.mkdir(parents=True, exist_ok=True)
    set_config_value("save_path", str(novels_dir))

    download_path.unlink(missing_ok=True)

    return {
        "success": True,
        "version": latest_version,
        "exe_path": str(_get_exe_path()),
        "download_source": msg,
    }


def _extract_and_install(archive_path: Path, target_dir: Path) -> bool:
    system = platform.system()
    exe_path = _get_exe_path()

    if archive_path.suffix == ".zip":
        try:
            with zipfile.ZipFile(str(archive_path), "r") as zf:
                for info in zf.infolist():
                    if info.filename.endswith(".exe") or (
                        not info.filename.endswith(".exe")
                        and not info.is_dir()
                        and "/" not in info.filename
                        and "." not in Path(info.filename).suffix
                    ):
                        info.filename = Path(info.filename).name
                        zf.extract(info, str(target_dir))
                        extracted = target_dir / info.filename
                        if system != "Windows" and extracted.exists():
                            extracted.chmod(0o755)
                        if extracted != exe_path:
                            shutil.move(str(extracted), str(exe_path))
                        return True
                zf.extractall(str(target_dir))
                for f in target_dir.iterdir():
                    if f.is_file() and f.suffix in (".exe", "") and f != exe_path:
                        if system != "Windows":
                            f.chmod(0o755)
                        shutil.move(str(f), str(exe_path))
                        return True
            return False
        except Exception as e:
            logger.error(f"解压失败: {e}")
            return False
    elif archive_path.suffix in (".gz", ".xz", ".bz2") or ".tar." in archive_path.name:
        import tarfile

        try:
            with tarfile.open(str(archive_path)) as tf:
                for member in tf.getmembers():
                    if member.isfile():
                        member.name = Path(member.name).name
                        tf.extract(member, str(target_dir))
                        extracted = target_dir / member.name
                        if system != "Windows" and extracted.exists():
                            extracted.chmod(0o755)
                        if extracted != exe_path:
                            shutil.move(str(extracted), str(exe_path))
                        return True
            return False
        except Exception as e:
            logger.error(f"解压 tar 失败: {e}")
            return False
    else:
        try:
            shutil.move(str(archive_path), str(exe_path))
            if system != "Windows":
                exe_path.chmod(0o755)
            return True
        except Exception as e:
            logger.error(f"安装失败: {e}")
            return False


def update_fanqie(
    use_mirror: bool = True,
    mirror: str = DEFAULT_MIRROR,
    prefer_musl: bool = False,
    progress_callback=None,
) -> Dict:
    current_version = get_installed_version()
    try:
        release_info = get_latest_release()
    except RuntimeError as e:
        return {"success": False, "error": str(e), "action": "check_failed"}

    latest_version = release_info.get("tag_name", "unknown")

    if current_version and compare_versions(current_version, latest_version) >= 0:
        return {
            "success": True,
            "action": "already_latest",
            "current_version": current_version,
            "latest_version": latest_version,
            "message": f"已是最新版本 ({current_version})",
        }

    result = install_fanqie(
        use_mirror=use_mirror,
        mirror=mirror,
        prefer_musl=prefer_musl,
        progress_callback=progress_callback,
    )
    result["action"] = "updated"
    result["previous_version"] = current_version
    return result


def check_update() -> Dict:
    current_version = get_installed_version()
    try:
        release_info = get_latest_release()
    except RuntimeError as e:
        return {"available": False, "error": str(e)}

    latest_version = release_info.get("tag_name", "unknown")
    has_update = not current_version or compare_versions(current_version, latest_version) < 0

    return {
        "available": has_update,
        "current_version": current_version,
        "latest_version": latest_version,
        "installed": is_installed(),
        "release_notes": release_info.get("body", "")[:500] if has_update else "",
    }


def launch_tui(
    data_dir: Optional[str] = None,
    extra_args: Optional[List[str]] = None,
) -> subprocess.Popen:
    if not is_installed():
        raise FileNotFoundError(
            "番茄小说下载器未安装，请先运行: ppc8 fanqie install"
        )

    exe_path = _get_exe_path()
    effective_data_dir = data_dir or str(_get_default_data_dir())
    cmd = [str(exe_path), "--data-dir", effective_data_dir]
    if extra_args:
        cmd.extend(extra_args)

    logger.info(f"启动番茄小说下载器 TUI: {' '.join(cmd)}")
    return subprocess.Popen(cmd)


def launch_server(
    host: str = "127.0.0.1",
    port: int = 18423,
    password: Optional[str] = None,
    data_dir: Optional[str] = None,
    extra_args: Optional[List[str]] = None,
) -> subprocess.Popen:
    if not is_installed():
        raise FileNotFoundError(
            "番茄小说下载器未安装，请先运行: ppc8 fanqie install"
        )

    exe_path = _get_exe_path()
    env = os.environ.copy()
    env["TOMATO_WEB_ADDR"] = f"{host}:{port}"
    if password:
        env["TOMATO_WEB_PASSWORD"] = password

    effective_data_dir = data_dir or str(_get_default_data_dir())
    cmd = [str(exe_path), "--server", "--data-dir", effective_data_dir]
    if extra_args:
        cmd.extend(extra_args)

    logger.info(f"启动番茄小说下载器 Server: {' '.join(cmd)}")
    return subprocess.Popen(cmd, env=env)


def update_book(book_id: str, data_dir: Optional[str] = None) -> Tuple[bool, str]:
    if not is_installed():
        return False, "番茄小说下载器未安装，请先运行: ppc8 fanqie install"

    exe_path = _get_exe_path()
    effective_data_dir = data_dir or str(_get_default_data_dir())
    cmd = [str(exe_path), "--update", book_id, "--data-dir", effective_data_dir]

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
        if result.returncode == 0:
            return True, result.stdout or "更新完成"
        else:
            return False, result.stderr or f"更新失败 (退出码: {result.returncode})"
    except subprocess.TimeoutExpired:
        return False, "更新超时"
    except Exception as e:
        return False, f"更新异常: {e}"


def get_status() -> Dict:
    installed = is_installed()
    current_version = get_installed_version()
    exe_path = _get_exe_path()

    status = {
        "installed": installed,
        "version": current_version,
        "exe_path": str(exe_path) if installed else None,
        "base_dir": str(_get_fanqie_base_dir()),
        "data_dir": str(_get_default_data_dir()),
        "config_path": str(_get_config_path()),
    }

    if installed:
        try:
            update_info = check_update()
            status["latest_version"] = update_info.get("latest_version")
            status["update_available"] = update_info.get("available", False)
        except Exception:
            status["latest_version"] = "unknown"
            status["update_available"] = None

    return status


def config_exists() -> bool:
    return _get_config_path().exists()


def read_config() -> Optional[str]:
    config_path = _get_config_path()
    if not config_path.exists():
        return None
    try:
        return config_path.read_text(encoding="utf-8")
    except Exception as e:
        logger.error(f"读取配置失败: {e}")
        return None


def write_config(content: str) -> bool:
    config_path = _get_config_path()
    try:
        config_path.parent.mkdir(parents=True, exist_ok=True)
        config_path.write_text(content, encoding="utf-8")
        logger.info(f"配置已写入: {config_path}")
        return True
    except Exception as e:
        logger.error(f"写入配置失败: {e}")
        return False


def get_config_value(key: str) -> Optional[str]:
    import yaml

    content = read_config()
    if content is None:
        return None
    try:
        data = yaml.safe_load(content)
        if data is None:
            return None
        keys = key.split(".")
        current = data
        for k in keys:
            if isinstance(current, dict) and k in current:
                current = current[k]
            else:
                return None
        return str(current) if current is not None else None
    except Exception as e:
        logger.error(f"读取配置项失败: {e}")
        return None


def set_config_value(key: str, value: str) -> bool:
    import yaml

    content = read_config()
    if content is None:
        data = {}
    else:
        try:
            data = yaml.safe_load(content) or {}
        except Exception:
            data = {}

    keys = key.split(".")
    current = data
    for k in keys[:-1]:
        if k not in current or not isinstance(current[k], dict):
            current[k] = {}
        current = current[k]

    parsed_value = value
    if value.lower() == "true":
        parsed_value = True
    elif value.lower() == "false":
        parsed_value = False
    else:
        try:
            parsed_value = int(value)
        except ValueError:
            try:
                parsed_value = float(value)
            except ValueError:
                pass

    current[keys[-1]] = parsed_value

    try:
        new_content = yaml.dump(data, allow_unicode=True, default_flow_style=False, sort_keys=False)
        return write_config(new_content)
    except Exception as e:
        logger.error(f"序列化配置失败: {e}")
        return False


def uninstall_fanqie() -> bool:
    base_dir = _get_fanqie_base_dir()
    if not base_dir.exists():
        return True
    try:
        shutil.rmtree(str(base_dir))
        logger.info("番茄小说下载器已卸载")
        return True
    except Exception as e:
        logger.error(f"卸载失败: {e}")
        return False
