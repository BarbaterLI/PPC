"""Result type

Provides Rust-style Result type for error handling.
"""

from typing import Any, Callable, Generic, TypeVar, Union

T = TypeVar("T")
E = TypeVar("E", bound=Exception)


class Result(Generic[T, E]):
    """Result type for error handling

    Supports monadic operations (map, and_then, or_else, etc.)
    """

    def __init__(self, ok: bool, value: Union[T, None] = None, error: Union[E, None] = None):
        self._ok = ok
        self._value = value
        self._error = error

    @classmethod
    def ok(cls, value: T) -> "Result[T, E]":
        """Create successful Result"""
        return cls(ok=True, value=value)

    @classmethod
    def err(cls, error: E) -> "Result[T, E]":
        """Create failed Result"""
        return cls(ok=False, error=error)

    @property
    def is_ok(self) -> bool:
        """Check if successful"""
        return self._ok

    @property
    def is_err(self) -> bool:
        """Check if failed"""
        return not self._ok

    @property
    def value(self) -> T:
        """Get value (raises if error)"""
        if not self._ok:
            raise self._error  # type: ignore
        return self._value  # type: ignore

    @property
    def error(self) -> E:
        """Get error (raises if ok)"""
        if self._ok:
            raise ValueError("No error")
        return self._error  # type: ignore

    def unwrap(self) -> T:
        """Unwrap value (raises if error)"""
        return self.value

    def unwrap_or(self, default: T) -> T:
        """Unwrap value or return default"""
        if self._ok:
            return self._value  # type: ignore
        return default

    def unwrap_or_else(self, func: Callable[[E], T]) -> T:
        """Unwrap value or call function to get default"""
        if self._ok:
            return self._value  # type: ignore
        return func(self._error)  # type: ignore

    def expect(self, message: str) -> T:
        """Unwrap value with custom message"""
        if not self._ok:
            raise ValueError(f"{message}: {self._error}")
        return self._value  # type: ignore

    def map(self, func: Callable[[T], Any]) -> "Result[Any, E]":
        """Map successful value"""
        if self._ok:
            return Result.ok(func(self._value))
        return Result.err(self._error)  # type: ignore

    def map_err(self, func: Callable[[E], Any]) -> "Result[T, Any]":
        """Map error value"""
        if self._ok:
            return Result.ok(self._value)  # type: ignore
        return Result.err(func(self._error))

    def and_then(self, func: Callable[[T], "Result[Any, E]"]) -> "Result[Any, E]":
        """Chain operation on success"""
        if self._ok:
            return func(self._value)
        return Result.err(self._error)  # type: ignore

    def or_else(self, func: Callable[[E], "Result[T, Any]"]) -> "Result[T, Any]":
        """Handle error with alternative"""
        if self._ok:
            return Result.ok(self._value)  # type: ignore
        return func(self._error)

    def to_dict(self) -> dict:
        """Convert to dictionary"""
        if self._ok:
            return {"ok": True, "value": self._value}
        return {"ok": False, "error": str(self._error)}

    def __repr__(self) -> str:
        if self._ok:
            return f"Ok({self._value!r})"
        return f"Err({self._error!r})"


class Ok(Result[T, E]):
    """Successful Result"""

    def __init__(self, value: T):
        super().__init__(ok=True, value=value)


class Err(Result[T, E]):
    """Failed Result"""

    def __init__(self, error: E):
        super().__init__(ok=False, error=error)


def is_ok(result: Result[T, E]) -> bool:
    """Check if Result is successful"""
    return result.is_ok


def is_err(result: Result[T, E]) -> bool:
    """Check if Result is failed"""
    return result.is_err
