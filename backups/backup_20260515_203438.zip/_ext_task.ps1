$extSource = 'd:\ppc8.1b1_main\PPC8s\src_m\extensions\fanqie'
$extPackage = 'd:\ppc8.1b1_main\PPC8s\fanqie_downloader.ppc9ext.zip'
$tempDir = Join-Path $env:TEMP "fanqie_ext_$(Get-Random)"

New-Item -ItemType Directory -Path $tempDir -Force | Out-Null

$manifestContent = @"
name: fanqie_downloader
version: 1.0.0
description: "番茄小说下载器集成 - 安装/更新/启动 TUI/Server"
author: "PPC9 Extension"
extension_type: tool_integration
entry: extension.py
dependencies: []
min_ppc9_version: "9.0.0"
tags:
  - fanqie
  - novel
  - downloader
  - tui
  - server
"@
Set-Content -Path (Join-Path $tempDir 'manifest.yml') -Value $manifestContent -Encoding UTF8

Copy-Item (Join-Path $extSource '__init__.py') $tempDir
Copy-Item (Join-Path $extSource 'extension.py') $tempDir
Copy-Item (Join-Path $extSource 'downloader.py') $tempDir

if (Test-Path $extPackage) { Remove-Item $extPackage -Force }

Compress-Archive -Path (Join-Path $tempDir '*') -DestinationPath $extPackage -Force

Remove-Item $tempDir -Recurse -Force

$size = (Get-Item $extPackage).Length / 1KB
Write-Host "Extension package created: $extPackage"
Write-Host "Size: $([math]::Round($size, 2)) KB"

Add-Type -AssemblyName System.IO.Compression
$archive = [System.IO.Compression.ZipFile]::OpenRead($extPackage)
Write-Host "`nPackage contents:"
foreach ($entry in $archive.Entries) {
    Write-Host "  $($entry.FullName) ($($entry.CompressedLength) bytes compressed)"
}
$archive.Dispose()
