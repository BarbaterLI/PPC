# PPC8 Code Wiki

> **PPC8** — 冰璃岩文本转语音工具 v8.3.0  
> 冰璃岩项目开发组 (BLY Team) 出品  
> 许可证：Apache License 2.0

---

## 目录

1. [项目概述](#1-项目概述)
2. [整体架构](#2-整体架构)
3. [目录结构](#3-目录结构)
4. [技术栈与依赖](#4-技术栈与依赖)
5. [核心模块详解](#5-核心模块详解)
   - 5.1 [入口与 CLI 层](#51-入口与-cli-层)
   - 5.2 [配置管理模块](#52-配置管理模块)
   - 5.3 [核心基础层](#53-核心基础层)
   - 5.4 [引擎层](#54-引擎层)
   - 5.5 [执行器层](#55-执行器层)
   - 5.6 [可靠性模块](#56-可靠性模块)
   - 5.7 [分布式模块](#57-分布式模块)
   - 5.8 [扩展系统](#58-扩展系统)
   - 5.9 [事件总线](#59-事件总线)
   - 5.10 [文本处理模块](#510-文本处理模块)
   - 5.11 [音频处理模块](#511-音频处理模块)
   - 5.12 [其他辅助模块](#512-其他辅助模块)
6. [关键类与接口索引](#6-关键类与接口索引)
7. [模块依赖关系](#7-模块依赖关系)
8. [数据流与处理管线](#8-数据流与处理管线)
9. [配置体系](#9-配置体系)
10. [项目运行方式](#10-项目运行方式)
11. [CLI 命令参考](#11-cli-命令参考)

---

## 1. 项目概述

PPC8 是一个功能完备的文本转语音 (TTS) 工具，核心能力包括：

- **文本分章**：支持中英文小说的智能章节检测与分割，支持自定义规则和卷章层级分割
- **TTS 语音合成**：基于 Edge TTS (Azure Neural TTS) 的语音合成，支持分段合成、并发处理
- **批量转换**：批量文本文件到音频文件的转换，支持断点续传
- **分布式计算**：Master-Node 架构的分布式 TTS 集群，支持负载均衡与容错
- **扩展系统**：可插拔的扩展框架，支持自定义负载均衡、健康检查、指标导出等
- **格式转换**：支持 EPUB/PDF/HTML/Markdown 等多种输出格式的生成
- **番茄小说集成**：内置番茄小说下载器扩展

---

## 2. 整体架构

PPC8 采用**分层架构**设计，自上而下分为：

```
┌─────────────────────────────────────────────────┐
│                  CLI 层 (typer)                  │
│  ppc8.py → typer_app.py → commands/*.py         │
├─────────────────────────────────────────────────┤
│                 执行器层 (Executors)              │
│  TTSExecutor / SplitterExecutor / Batcher / ...  │
├─────────────────────────────────────────────────┤
│                  引擎层 (Engines)                 │
│  TTSEngine / ChapterEngine / EPUBEngine / ...    │
├─────────────────────────────────────────────────┤
│              可靠性层 (Reliability)               │
│  RetryPolicy / CircuitBreaker / ExecutionResult  │
├─────────────────────────────────────────────────┤
│              基础设施层 (Infrastructure)           │
│  Config / EventBus / Extensions / Distributed    │
├─────────────────────────────────────────────────┤
│               工具层 (Utils/Text/Audio)           │
│  TextSegmenter / TextNormalizer / AudioProcessor │
└─────────────────────────────────────────────────┘
```

**核心设计原则**：

- **引擎-执行器分离**：引擎负责单一处理逻辑（如 TTS 合成），执行器负责编排（并发、重试、断点续传）
- **Rust 风格 Result 类型**：`ExecutionResult[T]` 统一成功/失败/部分成功的返回语义
- **熔断器模式**：`CircuitBreaker` 保护 TTS 和网络调用，防止级联故障
- **事件驱动**：`EventBus` 实现模块间松耦合通信
- **可插拔扩展**：通过 `Extension` 基类和 `ExtensionLoader` 实现用户自定义扩展

---

## 3. 目录结构

```
PPC8s/
├── ppc8.py                    # 主入口
├── config.yaml                # 主配置文件（详细注释版）
├── config.yml                 # 番茄小说下载器配置
├── requirements.txt           # Python 依赖
├── LICENSE                    # Apache 2.0
├── icon.ico                   # 应用图标
├── export_code.py             # 代码导出工具
├── clean_pycache.bat/sh       # 缓存清理脚本
├── fanqie/                    # 番茄小说下载器（独立可执行文件）
│   ├── TomatoNovelDownloader.exe
│   ├── config.yml
│   └── .version
└── src_m/                     # 核心源码
    ├── __init__.py
    ├── compat.py              # 兼容性层
    ├── cli/                   # CLI 命令层
    │   ├── typer_app.py       # Typer 应用定义
    │   ├── output.py          # 输出格式化
    │   ├── ui.py              # UI 工具
    │   ├── simple_progress.py # 简易进度条
    │   └── commands/          # 各子命令实现
    │       ├── convert.py     # TTS 转换命令
    │       ├── split.py       # 分章命令
    │       ├── batch.py       # 批量归档命令
    │       ├── config.py      # 配置管理命令
    │       ├── check.py       # 系统检查命令
    │       ├── analyze.py     # 深度分析命令
    │       ├── status.py      # 状态监控命令
    │       ├── distributed.py # 分布式管理命令
    │       ├── merge.py       # 音频合并命令
    │       ├── preview.py     # TTS 预览命令
    │       ├── fanqie.py      # 番茄小说命令
    │       └── ext.py         # 扩展管理命令
    ├── config/                # 配置管理
    │   ├── schema.py          # Pydantic 配置 Schema
    │   ├── manager.py         # 配置管理器
    │   ├── presets.py         # 预设配置
    │   └── migration.py       # 配置迁移
    ├── core/                  # 核心基础
    │   ├── base.py            # BaseEngine 抽象基类
    │   ├── models.py          # 数据模型（已迁移至 reliability）
    │   ├── errors.py          # 统一错误码枚举
    │   └── exceptions.py      # 异常层次结构
    ├── engines/               # 引擎层
    │   ├── tts_engine.py      # TTS 引擎
    │   ├── chapter_engine.py  # 分章引擎
    │   ├── epub_engine.py     # EPUB 生成引擎
    │   ├── html_engine.py     # HTML 生成引擎
    │   ├── markdown_engine.py # Markdown 生成引擎
    │   └── pdf_engine.py      # PDF 生成引擎
    ├── executors/             # 执行器层
    │   ├── base.py            # 执行器基类
    │   ├── tts.py             # TTS 执行器
    │   ├── splitter.py        # 分割执行器
    │   ├── batcher.py         # 批量执行器
    │   ├── merger.py          # 合并执行器
    │   ├── file_processor.py  # 文件处理器
    │   ├── checkpoint.py      # 断点续传管理
    │   ├── quarantine.py      # 隔离队列
    │   └── registry.py        # 执行器注册表
    ├── reliability/           # 可靠性保障
    │   ├── result.py          # Rust 风格 Result 类型
    │   ├── execution.py       # ExecutionResult / RetryPolicy
    │   ├── retry.py           # 重试机制
    │   ├── circuit.py         # 熔断器
    │   ├── rate_limiter.py    # 限流器
    │   └── errors.py          # 可靠性相关错误
    ├── distributed/           # 分布式计算
    │   ├── scheduler.py       # 统一分布式调度器
    │   ├── master_scheduler.py# 主控调度器
    │   ├── node_server.py     # 节点服务
    │   ├── node_pool.py       # 节点池管理
    │   ├── adaptive_lb.py     # 自适应负载均衡
    │   ├── fault_tolerance.py # 容错与迁移
    │   └── metrics.py         # 分布式指标
    ├── extensions/            # 扩展系统
    │   ├── base.py            # 扩展接口定义
    │   ├── loader.py          # 扩展加载器
    │   ├── package.py         # 扩展打包
    │   ├── fanqie/            # 番茄小说扩展
    │   │   ├── extension.py
    │   │   └── downloader.py
    │   └── examples/          # 扩展示例
    │       └── priority_lb.py
    ├── events/                # 事件总线
    │   └── event_bus.py       # 发布/订阅事件系统
    ├── text/                  # 文本处理
    │   ├── segmenter.py       # 文本分段器
    │   └── normalizer.py      # 文本规范化器
    ├── audio/                 # 音频处理
    │   ├── processor.py       # 音频处理器
    │   └── post_processor.py  # 音频后处理
    ├── cache/                 # 缓存
    │   └── multilevel_cache.py# 多级缓存
    ├── pool/                  # 资源池
    │   ├── connection_pool.py # 连接池
    │   └── memory_pool.py     # 内存池
    ├── timeout/               # 超时控制
    │   ├── calculator.py      # 超时计算器
    │   └── history.py         # 超时历史
    ├── scheduler/             # 任务调度
    │   ├── task_scheduler.py  # 任务调度器
    │   └── cron_scheduler.py  # Cron 调度器
    ├── analysis/              # 系统分析
    │   ├── engine.py          # 分析引擎
    │   ├── models.py          # 分析模型
    │   ├── diff.py            # 差异对比
    │   ├── history.py         # 分析历史
    │   ├── html_report.py     # HTML 报告
    │   ├── repair.py          # 自动修复
    │   └── analyzers/         # 各类分析器
    ├── logging/               # 日志
    │   └── structured_logger.py
    ├── profiler/              # 性能分析
    │   └── profiler.py
    ├── tracing/               # 链路追踪
    │   └── tracer.py
    ├── utils/                 # 工具函数
    │   ├── core.py            # 核心工具
    │   ├── keep_awake.py      # 防休眠
    │   └── ppc7.py            # PPC7 兼容
    ├── infrastructure/        # 基础设施适配
    │   ├── executor_adapter.py
    │   └── node_adapter.py
    ├── legacy/                # 遗留兼容
    │   └── ppc2_legacy.py
    └── webhook/               # Webhook 回调
        └── service.py
```

---

## 4. 技术栈与依赖

| 类别 | 技术 | 用途 |
|------|------|------|
| **语言** | Python 3.10+ | 主开发语言 |
| **CLI 框架** | Typer 0.25.0 + Rich 15.0.0 | 命令行界面 |
| **TTS 引擎** | edge-tts 7.2.8 | Azure Neural TTS 语音合成 |
| **音频处理** | pydub 0.25.1 | 音频合并、格式转换、验证 |
| **配置验证** | Pydantic 2.13.3 | 配置 Schema 定义与验证 |
| **配置格式** | PyYAML 6.0.3 | YAML 配置文件读写 |
| **Web 框架** | Flask 3.1.3 + Flask-CORS | 分布式节点 HTTP 服务 |
| **HTML 解析** | BeautifulSoup4 4.14.3 + lxml | EPUB/HTML 内容处理 |
| **系统监控** | psutil 7.2.2 | 系统资源监控 |
| **HTTP 客户端** | aiohttp | 分布式节点间通信 |
| **音频兼容** | audioop-lts | Python 3.13+ audioop 兼容 |
| **网络请求** | requests >= 2.31.0 | 番茄小说下载器 |
| **打包** | packaging >= 23.0 | 版本号处理 |

---

## 5. 核心模块详解

### 5.1 入口与 CLI 层

**入口文件**：[ppc8.py](file:///d:/ppc8.1b1_main/PPC8s/ppc8.py)

```python
def main():
    if "--legacy" in sys.argv or "-l" in sys.argv:
        from src_m.legacy import ppc2_main
        ppc2_main()          # 遗留模式
    else:
        from src_m.cli.typer_app import app
        app()                 # 新版 CLI
```

**CLI 应用**：[typer_app.py](file:///d:/ppc8.1b1_main/PPC8s/src_m/cli/typer_app.py)

- 使用 Typer 框架定义所有命令
- 支持延迟导入（`from .commands.convert import handle_convert`），减少启动时间
- 全局状态管理：`_output`（输出格式化器）、`_config`（配置）、`_extension_loader`（扩展加载器）

**命令注册表**：

| 命令 | 处理函数 | 功能 |
|------|----------|------|
| `convert` | `handle_convert` | 批量 TTS 转换 |
| `split` | `handle_split` | 章节分割 |
| `batch` | `handle_batch` | 批量归档 |
| `config` | `handle_config` | 配置管理 |
| `check` | `handle_check` | 系统检查 |
| `voices` | `handle_voices` | 列出可用语音 |
| `analyze` | `handle_analyze` | 系统深度分析 |
| `status` | `handle_status` | 状态监控仪表板 |
| `merge` | `handle_merge` | 合并音频文件 |
| `preview` | `handle_preview` | TTS 预览 |
| `dist node` | `node_start` | 启动分布式节点 |
| `dist status` | `distributed_status` | 查看分布式状态 |
| `dist add-node` | `add_node` | 添加分布式节点 |
| `fanqie *` | — | 番茄小说子命令组 |
| `ext *` | — | 扩展管理子命令组 |

---

### 5.2 配置管理模块

**路径**：`src_m/config/`

#### Schema 定义 — [schema.py](file:///d:/ppc8.1b1_main/PPC8s/src_m/config/schema.py)

使用 Pydantic v2 定义完整的配置 Schema，核心类：

| 类名 | 说明 |
|------|------|
| `PPC8Config` | 顶层配置容器，包含所有子配置 |
| `CoreConfig` | 核心配置（运行模式、日志级别、临时目录） |
| `TTSConfig` | TTS 配置（语音、并发、超时、分段、速率限制） |
| `SplitConfig` | 分割配置（预设、最小长度、编码、自定义规则） |
| `BatchConfig` | 批量处理配置 |
| `PerformanceConfig` | 性能配置（内存限制、连接池） |
| `ReliabilityConfig` | 可靠性配置（TTS/网络重试策略、熔断器） |
| `DistributedConfig` | 分布式配置（节点、负载均衡、容错） |
| `ExtensionConfig` | 扩展配置 |
| `CustomRule` | 自定义分割规则（支持正则、前缀、后缀等匹配类型） |
| `RuleCondition` | 规则前置条件（行号范围、上下文模式等） |

`CustomRule` 是分割系统的核心扩展点，支持：
- 5 种匹配类型：`regex` / `prefix` / `suffix` / `contains` / `exact`
- 11 种前置条件：前/后行空行、行首/行尾、行号范围、上下文模式等
- 标题提取：通过 `title_pattern` 正则捕获组
- 卷章层级：`is_volume_rule` 标记卷级别规则
- 条件组合：AND/OR 逻辑 + 反转

#### 配置管理器 — [manager.py](file:///d:/ppc8.1b1_main/PPC8s/src_m/config/manager.py)

`ConfigManager` 提供统一的配置管理接口：

- **多源加载**：默认预设 → PPC5 迁移 → 用户文件，优先级递增
- **热更新**：`update_config()` / `hot_update_concurrency()` 等方法支持运行时配置变更
- **监听器机制**：`add_listener()` 注册配置变更监听器，支持通配符匹配
- **版本管理**：`ConfigVersionManager` 支持配置版本保存与回滚
- **审计日志**：`ConfigAuditLogger` 记录所有配置变更
- **跨平台配置目录**：Windows (AppData) / macOS (Application Support) / Linux (.config)
- **冻结环境支持**：Nuitka/PyInstaller 打包后自动切换到用户数据目录

---

### 5.3 核心基础层

**路径**：`src_m/core/`

#### BaseEngine — [base.py](file:///d:/ppc8.1b1_main/PPC8s/src_m/core/base.py)

所有引擎的抽象基类，提供统一的生命周期管理：

```python
class BaseEngine(ABC, Generic[InputType, OutputType]):
    async def initialize(self) -> None    # 初始化
    async def cleanup(self) -> None       # 清理
    async def process(input_data, **kwargs) -> OutputType  # 处理
    def get_stats(self) -> EngineStats    # 统计信息
    # 支持异步上下文管理器 async with
```

`EngineStats` 数据类追踪：处理项数、失败数、取消数、字节数、峰值内存等。

#### 错误体系 — [errors.py](file:///d:/ppc8.1b1_main/PPC8s/src_m/core/errors.py) + [exceptions.py](file:///d:/ppc8.1b1_main/PPC8s/src_m/core/exceptions.py)

- `ErrorCodes`：统一错误码枚举（75+ 错误码），覆盖通用/文件/章节/TTS/网络/分布式/缓存/执行器/引擎等类别
- `PPC8Error`：基础异常类，支持 `error_code` 和 `details` 字典
- 异常层次：`EngineError` / `ExecutorError` / `ValidationError` / `TTSError` / `NetworkError` 等

---

### 5.4 引擎层

**路径**：`src_m/engines/`

#### TTSEngine — [tts_engine.py](file:///d:/ppc8.1b1_main/PPC8s/src_m/engines/tts_engine.py)

TTS 语音合成引擎，继承 `BaseEngine[str, Path]`：

| 方法 | 说明 |
|------|------|
| `synthesize(text, output_path)` | 单段合成，经 API 信号量控制并发 |
| `synthesize_segmented(text, output_path)` | 分段合成，长文本自动分段后串行合成再合并 |
| `synthesize_batch(tasks)` | 批量合成，Worker 信号量控制并发 |
| `_calculate_timeout(text)` | 动态超时计算，基于历史 P95 + 乘数 |
| `_execute_tts(communicate, output_path, timeout)` | 执行 Edge TTS 请求，含超时控制 |

**关键设计**：
- **双层并发控制**：`_api_semaphore` 控制 API 并发数，`_semaphore` 控制 Worker 并发数
- **动态超时**：基于 `TimeoutHistory` 的 P95 统计自动调整超时时间
- **文本预处理管线**：`TextNormalizer` → `TextSegmenter` → Edge TTS
- **熔断保护**：TTS 调用经过 `CircuitBreaker` 保护

#### ChapterEngine — [chapter_engine.py](file:///d:/ppc8.1b1_main/PPC8s/src_m/engines/chapter_engine.py)

章节检测与分割引擎，继承 `BaseEngine[str, List[Path]]`：

- 内置中文/英文/默认三套章节检测正则模式
- `_detect_chapters()` 逐行扫描匹配章节标题
- 支持最小章节长度过滤
- 支持标题分隔符（`========`）

#### 其他引擎

| 引擎 | 说明 |
|------|------|
| `EPUBEngine` | EPUB 电子书生成 |
| `HTMLEngine` | HTML 格式输出 |
| `MarkdownEngine` | Markdown 格式输出 |
| `PDFEngine` | PDF 格式输出 |

---

### 5.5 执行器层

**路径**：`src_m/executors/`

#### BaseExecutor — [base.py](file:///d:/ppc8.1b1_main/PPC8s/src_m/executors/base.py)

执行器基类，提供重试、熔断、进度回调等通用能力：

```python
class BaseExecutor(ABC, Generic[InputType, OutputType]):
    async def execute(input_path, output_path) -> ExecutionResult
    async def execute_with_retry(input_path, output_path) -> ExecutionResult
    async def run_with_circuit(task, *args) -> ExecutionResult
```

派生类：
- `BatchExecutor`：批量执行器，支持进度回调和取消
- `StreamingExecutor`：流式执行器，支持缓冲区刷新

#### TTSExecutor — [tts.py](file:///d:/ppc8.1b1_main/PPC8s/src_m/engines/tts_engine.py)

TTS 执行器，编排 TTS 批量转换任务：

| 方法 | 说明 |
|------|------|
| `execute(input_path, output_path)` | 执行单个 TTS 任务 |
| `add_batch_with_progress(...)` | 批量添加任务，支持进度回调和断点续传 |
| `enable_checkpoint(checkpoint_path)` | 启用断点续传 |
| `_worker_loop(worker_id)` | Worker 协程主循环（Sentinel 退出模式） |
| `_execute_task_with_retry(task, ...)` | 带重试的任务执行 |

**关键设计**：
- **Worker 池模式**：启动 N 个 Worker 协程从优先级队列取任务
- **Sentinel 退出**：任务完成后发送 `_SENTINEL` 信号优雅退出 Worker
- **隔离队列**：`QuarantineQueue` 隔离反复失败的任务
- **断点续传**：`CheckpointManager` 定期保存进度，重启后自动恢复

#### SplitterExecutor — [splitter.py](file:///d:/ppc8.1b1_main/PPC8s/src_m/executors/splitter.py)

分割执行器，支持扁平分割和卷章层级分割：

- `_split_flat()`：传统的章节级分割
- `_split_hierarchical()`：卷章两级分割（先检测卷，再在卷内检测章）
- `_detect_volumes()`：扫描全文识别卷标记
- `_check_rule_match()`：检查自定义规则匹配（含条件、排除模式、多行匹配等）

---

### 5.6 可靠性模块

**路径**：`src_m/reliability/`

#### ExecutionResult — [execution.py](file:///d:/ppc8.1b1_main/PPC8s/src_m/reliability/execution.py)

Rust 风格的执行结果包装器：

```python
class ExecutionResult(Generic[T]):
    @classmethod
    def success(cls, data, metrics) -> ExecutionResult[T]
    @classmethod
    def failure(cls, error, error_code) -> ExecutionResult[T]
    @classmethod
    def partial(cls, data, errors, metrics) -> ExecutionResult[T]  # 部分成功
```

关联类型：
- `ExecutionMetrics`：执行指标（耗时、内存、字节数、重试次数）
- `TaskResult`：单任务结果
- `BatchResult`：批量结果（total/succeeded/failed）
- `RetryPolicy`：重试策略配置

#### CircuitBreaker — [circuit.py](file:///d:/ppc8.1b1_main/PPC8s/src_m/reliability/circuit.py)

熔断器实现，三态模型：

```
CLOSED ──(失败率超阈值)──→ OPEN ──(超时后)──→ HALF_OPEN ──(成功达标)──→ CLOSED
                                  ↑                              │
                                  └────(半开状态失败)──────────────┘
```

关键特性：
- **滑动窗口计数器**：`SlidingWindowCounter` 追踪窗口内的成功/失败数
- **半开限流**：`HalfOpenLimiter` 限制半开状态的试探请求数
- **慢调用检测**：超过阈值的慢调用也触发熔断
- **Fallback 支持**：熔断时调用降级函数
- **全局注册表**：`get_circuit_breaker(name)` 获取或创建命名熔断器

#### RetryPolicy — [retry.py](file:///d:/ppc8.1b1_main/PPC8s/src_m/reliability/retry.py)

重试机制，支持：
- 指数退避 + 抖动 (jitter)
- 可配置的可重试/不可重试异常
- 同步 (`retry`) 和异步 (`retry_async`) 两种接口
- 超时控制
- 重试前后回调

#### Result 类型 — [result.py](file:///d:/ppc8.1b1_main/PPC8s/src_m/reliability/result.py)

Rust 风格的 `Result[T, E]` 类型，支持 monadic 操作：

```python
Result.ok(value)          # 创建成功结果
Result.err(error)         # 创建失败结果
result.unwrap()           # 解包（失败时抛出）
result.unwrap_or(default) # 解包或默认值
result.map(func)          # 映射成功值
result.and_then(func)     # 链式操作
result.or_else(func)      # 错误处理
```

---

### 5.7 分布式模块

**路径**：`src_m/distributed/`

#### DistributedScheduler — [scheduler.py](file:///d:/ppc8.1b1_main/PPC8s/src_m/distributed/scheduler.py)

统一分布式调度器，整合节点池管理和任务调度：

| 方法 | 说明 |
|------|------|
| `start()` | 启动调度器（初始化节点池、本地引擎、HTTP 会话、Worker） |
| `stop()` | 优雅停止 |
| `submit_task(task)` | 提交单个任务 |
| `submit_batch(tasks)` | 批量提交 |
| `add_node(host, port)` | 添加节点到池 |
| `set_load_balance_strategy(strategy)` | 注入自定义负载均衡策略 |

**任务执行流程**：
1. Worker 从队列取任务
2. 优先尝试远程节点执行 (`_execute_on_remote_node`)
3. 远程失败则回退到本地执行 (`_execute_on_local_node`)
4. 失败任务自动重试（可配置重试次数和延迟）

**负载均衡策略**：
- 内置：`round_robin` / `least_connections` / `best_response_time`
- 自定义：通过 `LoadBalanceStrategy` 接口注入

#### 其他组件

| 组件 | 说明 |
|------|------|
| `NodePool` | 节点池管理（添加/移除/健康检查/统计） |
| `NodeServer` | Flask 节点 HTTP 服务（`/api/v1/synthesize`） |
| `AdaptiveLoadBalancer` | 自适应负载均衡（考虑文本长度、历史性能） |
| `FaultTolerance` | 容错与任务迁移（降级策略、恢复检查） |

---

### 5.8 扩展系统

**路径**：`src_m/extensions/`

#### 扩展接口 — [base.py](file:///d:/ppc8.1b1_main/PPC8s/src_m/extensions/base.py)

定义了 6 种扩展类型和对应的抽象接口：

| 接口 | 类型 | 说明 |
|------|------|------|
| `Extension` | 基础 | 所有扩展的基类，提供 initialize/cleanup/事件发布 |
| `LoadBalanceStrategy` | 负载均衡 | `select_node(available_nodes, task_context)` |
| `HealthCheckStrategy` | 健康检查 | `check_node_health(node)` |
| `TaskSchedulingStrategy` | 任务调度 | `schedule_task(task, available_nodes)` |
| `MetricsExporter` | 指标导出 | `export_metrics(metrics_data)` |
| `ToolIntegration` | 工具集成 | `is_available()` / `get_info()` / `start()` / `stop()` |
| `ExecutorExtension` | 执行器 | `execute(task)` / `get_status()` |

`ExtensionMetadata` 包含：name, version, description, author, extension_type, tags, config, dependencies。

#### 扩展加载器 — [loader.py](file:///d:/ppc8.1b1_main/PPC8s/src_m/extensions/loader.py)

`ExtensionLoader` 负责：
- 从目录发现扩展（单文件 `.py` 或包目录）
- 动态加载（`importlib`）并验证接口兼容性
- 生命周期管理（initialize / enable / disable / cleanup）
- 内置番茄小说扩展 (`FanqieExtension`)

---

### 5.9 事件总线

**路径**：`src_m/events/event_bus.py`

`EventBus` 实现发布/订阅模式，支持同步和异步事件分发：

**内置事件类型**：

| 事件 | 说明 |
|------|------|
| `TaskStartedEvent` | 任务开始 |
| `TaskProgressEvent` | 任务进度 |
| `TaskCompletedEvent` | 任务完成 |
| `TaskFailedEvent` | 任务失败 |
| `RetryEvent` | 重试事件 |
| `CircuitBreakerEvent` | 熔断器状态变更 |
| `FormatConversionEvent` | 格式转换 |
| `AudioProcessedEvent` | 音频处理完成 |
| `ScheduledTaskEvent` | 定时任务 |
| `WebhookEvent` | Webhook 回调 |
| `ExtensionEvent` | 扩展事件 |

**特性**：
- 处理器优先级：`HIGHEST` → `HIGH` → `NORMAL` → `LOW` → `LOWEST`
- 事件过滤器：`filter_func` 过滤不需要的事件
- 全局订阅：`subscribe_global()` 订阅所有事件
- 事件历史：最多保留 1000 条事件记录
- 线程安全：使用 `threading.RLock` 和 `asyncio.Lock`

---

### 5.10 文本处理模块

**路径**：`src_m/text/`

#### TextSegmenter — [segmenter.py](file:///d:/ppc8.1b1_main/PPC8s/src_m/text/segmenter.py)

文本分段器，将长文本按标点符号智能分割：

- `split(text, max_length)`：主入口，返回不超过 `max_length` 的段列表
- `_find_split_point()`：在标点符号处寻找最佳分割点
- `_merge_short_segments()`：合并过短的相邻分段
- 支持从 `TTSConfig` 构建：`TextSegmenter.from_config(config)`

#### TextNormalizer — [normalizer.py](file:///d:/ppc8.1b1_main/PPC8s/src_m/text/normalizer.py)

文本规范化器，支持：
- 空白字符规范化
- 换行符规范化
- 标点符号规范化
- 行首尾空白去除
- 空行规范化（限制最大连续空行数）
- SSML/XML 标签清理

---

### 5.11 音频处理模块

**路径**：`src_m/audio/`

#### AudioProcessor — [processor.py](file:///d:/ppc8.1b1_main/PPC8s/src_m/audio/processor.py)

| 方法 | 说明 |
|------|------|
| `merge(audio_paths, output_path, silence_ms)` | 合并多个音频文件，片段间添加静音 |
| `validate(audio_path)` | 验证音频文件有效性 |
| `get_duration(audio_path)` | 获取音频时长 |
| `get_info(audio_path)` | 获取音频详细信息 |

#### AudioFormatConverter

支持 mp3/wav/ogg/aac/m4a/flac 格式互转，可配置比特率（64k/128k/192k）。

---

### 5.12 其他辅助模块

| 模块 | 路径 | 说明 |
|------|------|------|
| **缓存** | `src_m/cache/multilevel_cache.py` | 多级缓存系统 |
| **连接池** | `src_m/pool/connection_pool.py` | 自适应连接池（预热/健康检查/扩缩容） |
| **内存池** | `src_m/pool/memory_pool.py` | 分代内存池（年轻代/老年代/压缩/预取） |
| **超时控制** | `src_m/timeout/calculator.py` | 自适应超时计算（固定/自动/自适应模式） |
| **限流器** | `src_m/reliability/rate_limiter.py` | 令牌桶/滑动窗口限流 |
| **调度器** | `src_m/scheduler/task_scheduler.py` | 任务调度 |
| **Cron 调度** | `src_m/scheduler/cron_scheduler.py` | 定时任务调度 |
| **系统分析** | `src_m/analysis/engine.py` | 性能/配置/错误/依赖/网络/资源/代码质量分析 |
| **结构化日志** | `src_m/logging/structured_logger.py` | 结构化日志输出 |
| **性能分析** | `src_m/profiler/profiler.py` | 性能分析器 |
| **链路追踪** | `src_m/tracing/tracer.py` | 分布式链路追踪 |
| **防休眠** | `src_m/utils/keep_awake.py` | 阻止系统休眠 |
| **Webhook** | `src_m/webhook/service.py` | HTTP 回调通知服务 |
| **遗留兼容** | `src_m/legacy/ppc2_legacy.py` | PPC2 旧版 CLI 兼容 |

---

## 6. 关键类与接口索引

### 引擎层

| 类 | 文件 | 说明 |
|----|------|------|
| `BaseEngine[InputType, OutputType]` | `core/base.py` | 引擎抽象基类 |
| `TTSEngine` | `engines/tts_engine.py` | TTS 语音合成引擎 |
| `ChapterEngine` | `engines/chapter_engine.py` | 章节分割引擎 |
| `EPUBEngine` | `engines/epub_engine.py` | EPUB 生成引擎 |
| `EngineStats` | `core/base.py` | 引擎统计数据类 |

### 执行器层

| 类 | 文件 | 说明 |
|----|------|------|
| `BaseExecutor[InputType, OutputType]` | `executors/base.py` | 执行器抽象基类 |
| `BatchExecutor` | `executors/base.py` | 批量执行器基类 |
| `StreamingExecutor` | `executors/base.py` | 流式执行器基类 |
| `TTSExecutor` | `executors/tts.py` | TTS 执行器 |
| `SplitterExecutor` | `executors/splitter.py` | 分割执行器 |
| `TTSTask` | `executors/tts.py` | TTS 任务数据类 |

### 可靠性层

| 类 | 文件 | 说明 |
|----|------|------|
| `ExecutionResult[T]` | `reliability/execution.py` | 执行结果包装器 |
| `ExecutionMetrics` | `reliability/execution.py` | 执行指标 |
| `TaskResult` | `reliability/execution.py` | 单任务结果 |
| `BatchResult` | `reliability/execution.py` | 批量结果 |
| `RetryPolicy` | `reliability/execution.py` | 重试策略 |
| `CircuitBreaker` | `reliability/circuit.py` | 熔断器 |
| `Result[T, E]` | `reliability/result.py` | Rust 风格 Result 类型 |

### 配置层

| 类 | 文件 | 说明 |
|----|------|------|
| `PPC8Config` | `config/schema.py` | 顶层配置 |
| `ConfigManager` | `config/manager.py` | 配置管理器 |
| `ConfigVersionManager` | `config/manager.py` | 配置版本管理 |
| `ConfigAuditLogger` | `config/manager.py` | 配置审计日志 |
| `CustomRule` | `config/schema.py` | 自定义分割规则 |

### 分布式层

| 类 | 文件 | 说明 |
|----|------|------|
| `DistributedScheduler` | `distributed/scheduler.py` | 统一分布式调度器 |
| `TaskAssignment` | `distributed/scheduler.py` | 任务分配信息 |
| `NodePool` | `distributed/node_pool.py` | 节点池管理 |
| `NodeInfo` | `distributed/node_pool.py` | 节点信息 |

### 扩展层

| 类 | 文件 | 说明 |
|----|------|------|
| `Extension` | `extensions/base.py` | 扩展基类 |
| `ExtensionMetadata` | `extensions/base.py` | 扩展元数据 |
| `LoadBalanceStrategy` | `extensions/base.py` | 负载均衡策略接口 |
| `ExtensionLoader` | `extensions/loader.py` | 扩展加载器 |

### 事件层

| 类 | 文件 | 说明 |
|----|------|------|
| `EventBus` | `events/event_bus.py` | 事件总线 |
| `Event` | `events/event_bus.py` | 基础事件类 |

---

## 7. 模块依赖关系

```
ppc8.py
  └── cli.typer_app
        ├── cli.commands.convert ──→ executors.tts ──→ engines.tts_engine ──→ edge-tts
        │                           │                   ├── text.segmenter
        │                           │                   ├── text.normalizer
        │                           │                   ├── audio.processor ──→ pydub
        │                           │                   ├── timeout.calculator
        │                           │                   └── reliability (retry, circuit)
        │                           ├── executors.checkpoint
        │                           ├── executors.quarantine
        │                           └── config.manager ──→ config.schema (Pydantic)
        │
        ├── cli.commands.split ──→ executors.splitter ──→ engines.chapter_engine
        │
        ├── cli.commands.distributed ──→ distributed.scheduler ──→ aiohttp
        │                                 ├── distributed.node_pool
        │                                 ├── distributed.fault_tolerance
        │                                 └── extensions.base (LoadBalanceStrategy)
        │
        ├── cli.commands.analyze ──→ analysis.engine ──→ analysis.analyzers.*
        │
        ├── cli.commands.config ──→ config.manager
        │
        ├── cli.commands.fanqie ──→ extensions.fanqie
        │
        └── cli.commands.ext ──→ extensions.loader

跨层共享:
  reliability ←── engines, executors, distributed
  config ←── 几乎所有模块
  events.event_bus ←── extensions, reliability, distributed
  core.errors ←── engines, executors
  core.exceptions ←── reliability, engines, executors
```

---

## 8. 数据流与处理管线

### TTS 转换管线

```
输入目录 (*.txt)
    │
    ▼
TTSExecutor.add_batch_with_progress()
    │  扫描文件 → 创建 TTSTask → 入优先级队列
    │  断点续传：CheckpointManager.load() 恢复未完成任务
    ▼
Worker 协程池 (N 个)
    │  从队列取任务
    ▼
TTSExecutor.execute()
    │  读取文件 → 检测编码 → 读取文本
    ▼
TTSEngine.synthesize_segmented()
    │  文本 ≤ max_segment_length?
    │  ├── 是 → synthesize()
    │  └── 否 → TextSegmenter.split() → 逐段 synthesize() → AudioProcessor.merge()
    ▼
TTSEngine.synthesize()
    │  TextNormalizer.normalize()
    │  → 动态超时计算
    │  → edge_tts.Communicate.save() (API 信号量控制)
    │  → AudioProcessor.validate()
    │  → 记录超时历史
    ▼
输出音频文件 (*.mp3)
```

### 文本分割管线

```
输入文件 (*.txt)
    │
    ▼
SplitterExecutor.execute()
    │  检测编码 → 读取文本
    ▼
SplitterExecutor._split_content()
    │  hierarchical_split?
    │  ├── 是 → _split_hierarchical() (卷章两级)
    │  └── 否 → _split_flat() (扁平分割)
    ▼
_split_flat()
    │  逐行扫描 → 匹配预设/自定义规则 → 创建 ChapterInfo
    │  自定义规则检查：条件 → 排除模式 → 匹配 → 标题提取
    ▼
输出目录 (001_章节名.txt, 002_章节名.txt, ...)
```

### 分布式任务管线

```
主控端 (Master)
    │  DistributedScheduler.submit_batch()
    ▼
任务队列 (asyncio.Queue)
    │
    ▼
Worker 协程
    │  _select_best_node() (负载均衡)
    ▼
远程节点执行 (HTTP POST /api/v1/synthesize)
    │  失败? → 重试 / 回退本地执行
    ▼
本地执行 (TTSEngine.synthesize_segmented())
    │
    ▼
输出音频文件
```

---

## 9. 配置体系

### 配置加载优先级

```
默认预设 (balanced) < PPC5 迁移 < 用户配置文件 < 临时覆盖
```

### 配置预设

| 预设 | 说明 |
|------|------|
| `speed` | 速度优先（高并发、短超时） |
| `balanced` | 均衡模式（默认） |
| `quality` | 质量优先（低并发、长超时） |
| `custom` | 自定义配置 |

### 配置热更新

支持运行时修改以下配置项（无需重启）：
- `tts.concurrency` — 并发数
- `tts.timeout` — 超时时间
- `tts.voice` — 语音模型
- `core.log_level` — 日志级别

### 配置文件位置

| 环境 | 路径 |
|------|------|
| 开发模式 | 项目根目录 `config.yaml` |
| Windows 打包 | `%APPDATA%\PPC8\config.yaml` |
| macOS 打包 | `~/Library/Application Support/PPC8/config.yaml` |
| Linux 打包 | `~/.config/ppc8/config.yaml` |

---

## 10. 项目运行方式

### 环境准备

```bash
# 安装依赖
pip install -r requirements.txt

# 安装 ffmpeg（音频处理需要）
# Windows: choco install ffmpeg
# macOS: brew install ffmpeg
# Linux: sudo apt install ffmpeg
```

### 启动方式

```bash
# 标准模式
python ppc8.py <command> [options]

# 遗留模式 (PPC2 兼容)
python ppc8.py --legacy

# 查看版本
python ppc8.py --version
```

### 典型使用场景

```bash
# TTS 转换
python ppc8.py convert ./input_txt ./output_audio --voice zh-CN-XiaoxiaoNeural --concurrency 8

# 断点续传
python ppc8.py convert ./input_txt ./output_audio --resume

# 文本分章
python ppc8.py split novel.txt --preset chinese_novel

# 层级分割
python ppc8.py split novel.txt --hierarchical

# 批量归档
python ppc8.py batch ./chapters --batch-size 500

# 配置管理
python ppc8.py config show
python ppc8.py config set tts.concurrency 16
python ppc8.py config wizard

# 系统检查
python ppc8.py check --full

# 系统分析
python ppc8.py analyze --performance --network

# 音频合并
python ppc8.py merge *.mp3 -o combined.mp3 --silence 500

# TTS 预览
python ppc8.py preview "这是一段测试文本" --voice zh-CN-YunxiNeural

# 启动分布式节点
python ppc8.py dist node --host 0.0.0.0 --port 8000

# 查看分布式状态
python ppc8.py dist status
```

---

## 11. CLI 命令参考

### 全局选项

| 选项 | 说明 |
|------|------|
| `--verbose, -v` | 详细输出 |
| `--version` | 显示版本号 |

### convert — 批量 TTS 转换

| 选项 | 说明 | 默认值 |
|------|------|--------|
| `input_dir` | 输入目录 | (必填) |
| `output_dir` | 输出目录 | (必填) |
| `--voice, -v` | 语音模型 | 配置文件 |
| `--concurrency, -c` | 并发数 | 配置文件 |
| `--preset, -p` | 配置预设 | balanced |
| `--resume, -r` | 断点续传 | false |
| `--checkpoint` | 检查点文件路径 | 自动 |
| `--timeout-multiplier, -t` | 超时倍率 (0.5-2.0) | 配置文件 |
| `--rate` | 音频速度 | +0% |
| `--recursive, -R` | 递归处理子目录 | false |

### split — 章节分割

| 选项 | 说明 | 默认值 |
|------|------|--------|
| `input_file` | 输入文件 | (必填) |
| `--output, -o` | 输出目录 | 同目录 |
| `--preset, -p` | 章节预设 | chinese_novel |
| `--custom-rules, -r` | 自定义规则 JSON | 无 |
| `--add-title-separator` | 标题后加分隔符 | 配置文件 |
| `--hierarchical, -H` | 卷章层级分割 | false |

### batch — 批量归档

| 选项 | 说明 | 默认值 |
|------|------|--------|
| `source_dir` | 源目录 | (必填) |
| `--batch-size, -b` | 每批次文件数 | 配置文件 |
| `--dry-run, -d` | 预览模式 | false |
| `--group-by-volume, -g` | 按卷归档 | false |

### config — 配置管理

| 操作 | 说明 |
|------|------|
| `show` | 显示完整配置 |
| `get` | 获取指定配置项 |
| `set` | 设置配置项 |
| `reset` | 重置为预设 |
| `export` | 导出配置到文件 |
| `import` | 从文件导入配置 |
| `init` | 初始化配置文件 |
| `path` | 显示配置文件路径 |
| `wizard` | 交互式配置向导 |

### analyze — 系统深度分析

| 选项 | 说明 |
|------|------|
| `--performance, -p` | 性能分析 |
| `--config, -c` | 配置冲突检测 |
| `--errors, -e` | 错误模式识别 |
| `--dependency` | 依赖分析 |
| `--network` | 网络分析 |
| `--resource` | 资源分析 |
| `--quality` | 代码质量分析 |
| `--fix, -f` | 自动修复 |
| `--diff` | 与历史对比 |
| `--watch, -w` | 持续监控 |
| `--export-html` | 导出 HTML 报告 |

### dist — 分布式管理

| 子命令 | 说明 |
|--------|------|
| `node` | 启动 TTS 节点服务 |
| `status` | 查看分布式状态 |
| `add-node` | 添加分布式节点 |

### merge — 音频合并

| 选项 | 说明 | 默认值 |
|------|------|--------|
| `input_files` | 输入文件（支持通配符） | (必填) |
| `--output, -o` | 输出文件 | (必填) |
| `--silence, -s` | 静音间隔 (ms) | 500 |
| `--format, -f` | 输出格式 | mp3 |
| `--normalize` | 归一化音量 | true |

### preview — TTS 预览

| 选项 | 说明 | 默认值 |
|------|------|--------|
| `text` | 预览文本 | (必填) |
| `--voice, -v` | 语音名称 | zh-CN-XiaoxiaoNeural |
| `--rate, -r` | 语速调整 | +0% |
| `--output, -o` | 输出文件 | 无 |
| `--duration, -d` | 最大时长 (秒) | 10 |
