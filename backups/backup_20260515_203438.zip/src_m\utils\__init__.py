"""Public API for src_m.utils."""

from __future__ import annotations

from .core import (
    ObjectPool,
    MemoryMonitor,
    PerformanceStats,
    BaseComponent,
    AsyncObjectPool,
    RateLimiter,
    CircularBuffer,
    memory_efficient,
    retry_on_failure,
)
from .keep_awake import ScreenKeepAwake
from .ppc7 import ByteOrder, CacheAligned, Prefetcher, is_ppc7_platform, get_platform_info

__all__ = [
    "ObjectPool",
    "MemoryMonitor",
    "PerformanceStats",
    "BaseComponent",
    "AsyncObjectPool",
    "RateLimiter",
    "CircularBuffer",
    "memory_efficient",
    "retry_on_failure",
    "ScreenKeepAwake",
    "ByteOrder",
    "CacheAligned",
    "Prefetcher",
    "is_ppc7_platform",
    "get_platform_info",
]
