$timestamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$backupName = "backup_$timestamp.zip"
$sourcePath = 'd:\ppc8.1b1_main\PPC8s'
$backupPath = Join-Path $sourcePath $backupName

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

$zip = [System.IO.Compression.ZipFile]::Open($backupPath, 'Create')
$files = Get-ChildItem -Path $sourcePath -Recurse -File | Where-Object {
    $_.FullName -notlike '*\__pycache__\*' -and
    $_.Name -ne $backupName -and
    $_.Extension -ne '.zip'
}
$count = 0
foreach ($file in $files) {
    $relativePath = $file.FullName.Substring($sourcePath.Length + 1)
    [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $file.FullName, $relativePath)
    $count++
}
$zip.Dispose()

$size = (Get-Item $backupPath).Length / 1MB
Write-Host "Backup created: $backupPath"
Write-Host "Files included: $count"
Write-Host "Size: $([math]::Round($size, 2)) MB"
