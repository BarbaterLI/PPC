"""Core data models - compatibility layer.

Note: This module is deprecated and retained for backward compatibility only.
All data models have been migrated to src_m.reliability.result.

New code should import directly from src_m.reliability:
    from src_m.reliability import ExecutionResult, ExecutionMetrics, TaskResult, BatchResult
"""

from __future__ import annotations

import warnings

warnings.warn(
    "src_m.core.models is deprecated; import from src_m.reliability instead",
    DeprecationWarning,
    stacklevel=2,
)

try:
    from src_m.reliability.result import (
        BatchResult,
        ExecutionMetrics,
        ExecutionResult,
        ResultStatus,
        TaskInfo,
        TaskResult,
    )

    __all__ = [
        "BatchResult",
        "ExecutionMetrics",
        "ExecutionResult",
        "ResultStatus",
        "TaskInfo",
        "TaskResult",
    ]
except ImportError:
    # Models not yet available in src_m.reliability.result
    # This module is deprecated; new code should import from src_m.reliability
    __all__ = []
