"""PPC 核心工具类与函数。

提供对象池、内存监控、性能追踪、限速器、异步池、重试机制及通用工具。
"""

from __future__ import annotations

import asyncio
import functools
import gc
import logging
import queue
import re
import threading
import time
import tracemalloc
from collections import deque
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Callable, Optional, Dict, List, TypeVar, Awaitable, Tuple

logger = logging.getLogger(__name__)

T = TypeVar("T")

FILENAME_SANITIZE_PATTERN = re.compile(r'[<>:"/\\|?*\x00-\x1F]')
DEFAULT_FILENAME_MAX_LENGTH = 100
DEFAULT_ENCODING_FALLBACK = ["utf-8", "gbk", "gb2312", "utf-16"]
DEFAULT_ENCODING_DETECT_BUFFER = 1024


def sanitize_filename(filename: str, max_length: int = DEFAULT_FILENAME_MAX_LENGTH) -> str:
    """清理文件名中的非法字符。
    
    Args:
        filename: 原始文件名
        max_length: 最大文件名长度
        
    Returns:
        清理后的文件名
    """
    cleaned = FILENAME_SANITIZE_PATTERN.sub("_", filename)
    cleaned = cleaned.strip(". ")
    return cleaned[:max_length]


def detect_encoding(
    file_path: Path,
    encodings: Optional[List[str]] = None,
    detect_buffer: int = DEFAULT_ENCODING_DETECT_BUFFER,
) -> Optional[str]:
    """检测文件编码。
    
    Args:
        file_path: 文件路径
        encodings: 编码候选列表，默认为 ["utf-8", "gbk", "gb2312", "utf-16"]
        detect_buffer: 检测缓冲区大小（字节）
        
    Returns:
        检测到的编码，失败时返回 None
    """
    if encodings is None:
        encodings = DEFAULT_ENCODING_FALLBACK
        
    for encoding in encodings:
        try:
            with file_path.open("r", encoding=encoding) as f:
                f.read(detect_buffer)
            logger.debug(f"编码检测成功: {file_path.name} -> {encoding}")
            return encoding
        except (UnicodeDecodeError, UnicodeError):
            continue
    
    logger.warning(f"编码检测失败: {file_path.name}")
    return None


class ObjectPool:
    """Thread-safe object pool with factory-based creation and reuse tracking."""

    def __init__(self, factory: Callable[[], Any], max_size: int = 100) -> None:
        self.factory = factory
        self.max_size = max_size
        self._pool: queue.Queue = queue.Queue(maxsize=max_size)
        self.created = 0
        self.reused = 0

    def get(self) -> Any:
        """Retrieve an object from the pool, or create a new one if empty."""
        try:
            obj = self._pool.get_nowait()
            self.reused += 1
            return obj
        except queue.Empty:
            self.created += 1
            return self.factory()

    def put(self, obj: Any) -> None:
        """Return an object to the pool if space is available."""
        try:
            self._pool.put_nowait(obj)
        except queue.Full:
            pass

    def clear(self) -> None:
        """Remove all objects from the pool."""
        while not self._pool.empty():
            try:
                self._pool.get_nowait()
            except queue.Empty:
                break

    def get_stats(self) -> Dict[str, Any]:
        total = self.created + self.reused
        return {
            "created": self.created,
            "reused": self.reused,
            "pool_size": self._pool.qsize(),
            "max_size": self.max_size,
            "reuse_rate": self.reused / total if total > 0 else 0.0,
        }


class MemoryMonitor:
    """Monitors memory usage via tracemalloc with threshold-based GC triggering."""

    def __init__(self, threshold_mb: int = 768) -> None:
        self.threshold = threshold_mb * 1024 * 1024
        self.peak_usage = 0
        self.check_count = 0
        self.gc_triggered = 0
        self._lock = threading.Lock()

    def check_memory(self) -> bool:
        """Check current memory usage; trigger GC if above threshold.

        Returns True if memory pressure is detected.
        """
        if not tracemalloc.is_tracing():
            return False

        current = tracemalloc.get_traced_memory()[0]
        self.check_count += 1

        with self._lock:
            if current > self.peak_usage:
                self.peak_usage = current

        if current > self.threshold:
            gc.collect()
            self.gc_triggered += 1
            logger.warning(
                "Memory usage high (%.1fMB/%.1fMB), GC triggered (count: %d)",
                current / 1024 / 1024,
                self.threshold / 1024 / 1024,
                self.gc_triggered,
            )
            return True
        return False

    def get_stats(self) -> Dict[str, Any]:
        current = tracemalloc.get_traced_memory()[0] if tracemalloc.is_tracing() else 0
        return {
            "current_mb": current / 1024 / 1024,
            "peak_mb": self.peak_usage / 1024 / 1024,
            "threshold_mb": self.threshold / 1024 / 1024,
            "check_count": self.check_count,
            "gc_triggered": self.gc_triggered,
            "is_tracing": tracemalloc.is_tracing(),
        }

    def is_memory_pressure(self) -> bool:
        """Check if memory usage exceeds 80% of threshold."""
        if not tracemalloc.is_tracing():
            return False
        current = tracemalloc.get_traced_memory()[0]
        return current > self.threshold * 0.8


@dataclass
class PerformanceStats:
    """Tracks task performance metrics including throughput and success rate."""

    total_tasks: int = 0
    successful_tasks: int = 0
    failed_tasks: int = 0
    total_processing_time: float = 0.0
    peak_memory_mb: float = 0.0
    avg_processing_time: float = 0.0
    throughput_per_hour: float = 0.0

    def update_success(self, duration: float) -> None:
        self.total_tasks += 1
        self.successful_tasks += 1
        self.total_processing_time += duration
        self._recalculate()

    def update_failure(self) -> None:
        self.total_tasks += 1
        self.failed_tasks += 1
        self._recalculate()

    def _recalculate(self) -> None:
        if self.successful_tasks > 0:
            self.avg_processing_time = self.total_processing_time / self.successful_tasks
            self.throughput_per_hour = 3600.0 / self.avg_processing_time
        else:
            self.avg_processing_time = 0.0
            self.throughput_per_hour = 0.0

    def get_success_rate(self) -> float:
        if self.total_tasks == 0:
            return 0.0
        return (self.successful_tasks / self.total_tasks) * 100

    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_tasks": self.total_tasks,
            "successful_tasks": self.successful_tasks,
            "failed_tasks": self.failed_tasks,
            "total_processing_time": self.total_processing_time,
            "peak_memory_mb": self.peak_memory_mb,
            "avg_processing_time": self.avg_processing_time,
            "throughput_per_hour": self.throughput_per_hour,
            "success_rate": self.get_success_rate(),
        }


class BaseComponent(ABC):
    """Base class for components with lifecycle management and config access."""

    def __init__(self, config: Optional[Dict[str, Any]] = None) -> None:
        self.config: Dict[str, Any] = config or {}
        self.initialized = False
        self._lock = threading.RLock()

    @abstractmethod
    async def initialize(self) -> None:
        ...

    @abstractmethod
    async def cleanup(self) -> None:
        ...

    def get_config(self, key: str, default: Any = None) -> Any:
        return self.config.get(key, default)

    def set_config(self, key: str, value: Any) -> None:
        with self._lock:
            self.config[key] = value

    def is_initialized(self) -> bool:
        return self.initialized


class AsyncObjectPool:
    """Async-compatible object pool using asyncio.Queue."""

    def __init__(self, factory: Callable[[], Any], max_size: int = 100) -> None:
        self.factory = factory
        self.max_size = max_size
        self._pool: asyncio.Queue = asyncio.Queue(maxsize=max_size)
        self.created = 0
        self.reused = 0

    async def get(self) -> Any:
        """Retrieve an object from the pool, or create a new one if empty."""
        try:
            obj = self._pool.get_nowait()
            self.reused += 1
            return obj
        except asyncio.QueueEmpty:
            self.created += 1
            return self.factory()

    async def put(self, obj: Any) -> None:
        """Return an object to the pool if space is available."""
        try:
            await self._pool.put(obj)
        except asyncio.QueueFull:
            pass

    async def clear(self) -> None:
        """Remove all objects from the pool."""
        while not self._pool.empty():
            try:
                self._pool.get_nowait()
            except asyncio.QueueEmpty:
                break

    async def __aenter__(self) -> Any:
        return await self.get()

    async def __aexit__(
        self,
        exc_type: Optional[type],
        exc_val: Optional[Exception],
        exc_tb: Optional[Any],
    ) -> None:
        pass


class RateLimiter:
    """Token-bucket-style rate limiter with sliding window."""

    def __init__(self, max_requests: int, time_window: float = 1.0) -> None:
        self.max_requests = max_requests
        self.time_window = time_window
        self._requests: deque = deque()
        self._lock = threading.Lock()

    async def acquire(self) -> None:
        """Wait until a request slot is available."""
        async with asyncio.Lock():
            now = time.time()
            with self._lock:
                self._prune_old(now)
                if len(self._requests) >= self.max_requests:
                    wait_time = self.time_window - (now - self._requests[0])
                    if wait_time > 0:
                        await asyncio.sleep(wait_time)
                        now = time.time()
                        self._prune_old(now)

                self._requests.append(now)

    def _prune_old(self, now: float) -> None:
        """Remove timestamps older than the current window."""
        cutoff = now - self.time_window
        while self._requests and self._requests[0] <= cutoff:
            self._requests.popleft()

    def get_stats(self) -> Dict[str, Any]:
        with self._lock:
            now = time.time()
            active = sum(1 for t in self._requests if (now - t) < self.time_window)
            return {
                "max_requests": self.max_requests,
                "time_window": self.time_window,
                "current_requests": active,
                "total_requests": len(self._requests),
            }


class CircularBuffer:
    """Fixed-size circular buffer using deque with automatic eviction."""

    def __init__(self, max_size: int = 1000) -> None:
        self.max_size = max_size
        self._buffer: deque = deque(maxlen=max_size)

    def append(self, item: Any) -> None:
        self._buffer.append(item)

    def get_all(self) -> List[Any]:
        return list(self._buffer)

    def get_recent(self, count: int) -> List[Any]:
        return list(self._buffer)[-count:]

    def clear(self) -> None:
        self._buffer.clear()

    def size(self) -> int:
        return len(self._buffer)

    def is_full(self) -> bool:
        return len(self._buffer) >= self.max_size


def memory_efficient(func: Callable) -> Callable:
    """Decorator that clears the attached object pool after each call."""

    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        try:
            return func(*args, **kwargs)
        finally:
            pool = getattr(func, "_object_pool", None)
            if pool is not None:
                pool.clear()

    return wrapper


def retry_on_failure(
    max_retries: int = 3,
    backoff_factor: float = 2.0,
    exceptions: Tuple[type, ...] = (Exception,),
) -> Callable:
    """Async retry decorator with exponential backoff."""

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            last_exception: Optional[Exception] = None
            for attempt in range(max_retries):
                try:
                    return await func(*args, **kwargs)
                except exceptions as exc:
                    last_exception = exc
                    if attempt < max_retries - 1:
                        delay = backoff_factor ** attempt
                        logger.warning(
                            "%s failed (attempt %d/%d), retrying in %.1fs: %s",
                            func.__name__,
                            attempt + 1,
                            max_retries,
                            delay,
                            exc,
                        )
                        await asyncio.sleep(delay)
                    else:
                        logger.error(
                            "%s failed after %d attempts",
                            func.__name__,
                            max_retries,
                        )
            raise last_exception

        return wrapper

    return decorator


__all__ = [
    "ObjectPool",
    "MemoryMonitor",
    "PerformanceStats",
    "BaseComponent",
    "AsyncObjectPool",
    "RateLimiter",
    "CircularBuffer",
    "memory_efficient",
    "retry_on_failure",
    "sanitize_filename",
    "detect_encoding",
    "FILENAME_SANITIZE_PATTERN",
    "DEFAULT_FILENAME_MAX_LENGTH",
    "DEFAULT_ENCODING_FALLBACK",
    "DEFAULT_ENCODING_DETECT_BUFFER",
]
