"""Pool management module

Provides connection pool, memory pool, audio buffer pool, and memory monitoring functionality.
"""

from .connection_pool import (
    ConnectionInfo,
    ConnectionPool,
    ConnectionPoolConfig,
    ConnectionPoolManager,
    HTTPConnectionPool,
    ManagedPoolInfo,
    PoolState,
    PoolStats,
    create_default_pool_manager,
    create_http_pool,
)
from .memory_pool import (
    AudioBuffer,
    AudioBufferConfig,
    AudioBufferPool,
    AudioBufferPoolExhaustedError,
    AudioBufferStats,
    MemoryMonitor,
    MemoryMonitorConfig,
    MemoryPool,
    MemoryPoolConfig,
    MemoryPoolExhaustedError,
    MemoryPoolStats,
    MemoryPressureLevel,
    MemorySnapshot,
    create_audio_buffer_pool,
    create_default_memory_pool,
)

__all__ = [
    "ConnectionInfo",
    "ConnectionPool",
    "ConnectionPoolConfig",
    "ConnectionPoolManager",
    "HTTPConnectionPool",
    "ManagedPoolInfo",
    "PoolState",
    "PoolStats",
    "create_default_pool_manager",
    "create_http_pool",
    "AudioBuffer",
    "AudioBufferConfig",
    "AudioBufferPool",
    "AudioBufferPoolExhaustedError",
    "AudioBufferStats",
    "MemoryMonitor",
    "MemoryMonitorConfig",
    "MemoryPool",
    "MemoryPoolConfig",
    "MemoryPoolExhaustedError",
    "MemoryPoolStats",
    "MemoryPressureLevel",
    "MemorySnapshot",
    "create_audio_buffer_pool",
    "create_default_memory_pool",
]
