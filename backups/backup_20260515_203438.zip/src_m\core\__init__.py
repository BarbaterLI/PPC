"""PPC8 Core Abstraction Layer.

Provides unified engine and executor base classes, core data models,
and a comprehensive exception hierarchy.

Public API:
- BaseEngine: Unified engine abstract base class
- BaseExecutor: Optimized executor base class
- EngineStats: Engine/executor statistics
- ExecutionResult: Unified execution result type
- ExecutionMetrics: Execution metrics
- ResultStatus: Result status enum
- TaskInfo: Task information
- TaskResult: Task result
- BatchResult: Batch processing result
- Core exception types
"""

from __future__ import annotations

from .base import BaseEngine, EngineStats
from ..executors.base import BaseExecutor
from .exceptions import (
    PPC8Error,
    EngineError,
    ExecutorError,
    InitializationError,
    CleanupError,
    ValidationError,
    ConfigurationError,
    PPCTimeoutError as TimeoutError,
    NetworkError,
    FileIOError,
    TTSError,
    ChapterError,
)
try:
    from .models import (
        BatchResult,
        ExecutionMetrics,
        ExecutionResult,
        ResultStatus,
        TaskInfo,
        TaskResult,
    )
    _MODEL_EXPORTS = [
        "ResultStatus",
        "ExecutionMetrics",
        "ExecutionResult",
        "TaskInfo",
        "TaskResult",
        "BatchResult",
    ]
except ImportError:
    _MODEL_EXPORTS = []

__all__ = [
    # Base classes
    "BaseEngine",
    "BaseExecutor",
    "EngineStats",
    # Exceptions
    "PPC8Error",
    "EngineError",
    "ExecutorError",
    "InitializationError",
    "CleanupError",
    "ValidationError",
    "ConfigurationError",
    "TimeoutError",
    "NetworkError",
    "FileIOError",
    "TTSError",
    "ChapterError",
]
__all__.extend(_MODEL_EXPORTS)

__version__ = "8.3.0"
