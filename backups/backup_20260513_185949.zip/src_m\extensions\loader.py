"""扩展加载器 - 发现和加载用户自定义扩展。"""

import importlib
import importlib.util
import logging
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Type

from src_m.extensions.base import (
    Extension,
    ExtensionMetadata,
    ExtensionType,
    LoadBalanceStrategy,
    HealthCheckStrategy,
    TaskSchedulingStrategy,
    MetricsExporter,
)

logger = logging.getLogger(__name__)

REQUIRED_INTERFACES = {
    ExtensionType.LOAD_BALANCE_STRATEGY: LoadBalanceStrategy,
    ExtensionType.HEALTH_CHECK_STRATEGY: HealthCheckStrategy,
    ExtensionType.TASK_SCHEDULING_STRATEGY: TaskSchedulingStrategy,
    ExtensionType.METRICS_EXPORTER: MetricsExporter,
}


class ExtensionLoader:
    """加载并管理用户自定义扩展。"""

    def __init__(self, extension_dirs: Optional[List[Path]] = None):
        self._extension_dirs = extension_dirs or []
        self._loaded_extensions: Dict[str, Extension] = {}
        self._failed_extensions: List[Dict[str, str]] = []

    def add_extension_dir(self, directory: Path) -> None:
        """添加要扫描的扩展目录。"""
        if directory.exists() and directory.is_dir():
            self._extension_dirs.append(directory)
            logger.info(f"Extension directory added: {directory}")
        else:
            logger.warning(f"Extension directory does not exist: {directory}")

    async def load_all_extensions(self) -> Dict[str, Extension]:
        """加载已注册目录中的所有扩展。"""
        for directory in self._extension_dirs:
            await self._load_extensions_from_dir(directory)

        logger.info(
            f"Extensions loaded: {len(self._loaded_extensions)}, "
            f"failed: {len(self._failed_extensions)}"
        )
        return self._loaded_extensions.copy()

    async def _load_extensions_from_dir(self, directory: Path) -> None:
        """从目录扫描并加载扩展。"""
        for py_file in directory.glob("*.py"):
            if py_file.name.startswith("_"):
                continue

            await self._load_extension_from_file(py_file)

    async def _load_extension_from_file(self, file_path: Path) -> None:
        """加载单个扩展模块。"""
        module_name = file_path.stem
        spec = None

        try:
            spec = importlib.util.spec_from_file_location(module_name, file_path)
            if spec is None or spec.loader is None:
                raise ImportError(f"Cannot load spec from {file_path}")

            module = importlib.util.module_from_spec(spec)
            sys.modules[module_name] = module
            spec.loader.exec_module(module)

            extension = self._find_extension_instance(module)
            if extension is not None:
                if self._validate_extension(extension):
                    await extension.initialize()
                    self._loaded_extensions[extension.metadata.name] = extension
                    logger.info(f"Extension loaded successfully: {extension.metadata.name}")
                else:
                    self._record_failure(file_path.name, "Interface validation failed")
            else:
                self._record_failure(file_path.name, "No extension class found")

        except Exception as e:
            self._record_failure(file_path.name, str(e))
            logger.warning(f"Failed to load extension {file_path.name}: {e}")

    def _find_extension_instance(self, module) -> Optional[Extension]:
        """在模块中查找扩展实例。"""
        for attr_name in dir(module):
            attr = getattr(module, attr_name)
            if isinstance(attr, Extension):
                return attr
        return None

    def _validate_extension(self, extension: Extension) -> bool:
        """验证扩展是否实现了所需接口。"""
        if extension.metadata.extension_type is None:
            return True

        required_interface = REQUIRED_INTERFACES.get(extension.metadata.extension_type)
        if required_interface is None:
            return True

        return isinstance(extension, required_interface)

    def _record_failure(self, filename: str, error: str) -> None:
        """记录加载失败的扩展。"""
        self._failed_extensions.append({
            "filename": filename,
            "error": error,
        })

    def get_loaded_extensions(self) -> Dict[str, Extension]:
        """获取所有已加载的扩展。"""
        return self._loaded_extensions.copy()

    def get_failed_extensions(self) -> List[Dict[str, str]]:
        """获取加载失败的扩展信息。"""
        return self._failed_extensions.copy()

    def get_extensions_by_type(self, extension_type: ExtensionType) -> List[Extension]:
        """按类型获取扩展。"""
        return [
            ext for ext in self._loaded_extensions.values()
            if ext.metadata.extension_type == extension_type
        ]

    def clear(self) -> None:
        """清除所有已加载的扩展。"""
        for ext in self._loaded_extensions.values():
            try:
                ext.cleanup()
            except Exception as e:
                logger.warning(f"Error cleaning up extension {ext.metadata.name}: {e}")

        self._loaded_extensions.clear()
        self._failed_extensions.clear()
