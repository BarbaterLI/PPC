"""User-defined extension framework for PPC8 distributed TTS system.

This package provides extension points and loading mechanisms for users
to create custom extensions that integrate with the distributed system.
"""

from src_m.extensions.base import (
    Extension,
    ExtensionMetadata,
    ExtensionType,
    LoadBalanceStrategy,
    HealthCheckStrategy,
    TaskSchedulingStrategy,
    MetricsExporter,
)
from src_m.extensions.loader import ExtensionLoader

__all__ = [
    "Extension",
    "ExtensionMetadata",
    "ExtensionType",
    "LoadBalanceStrategy",
    "HealthCheckStrategy",
    "TaskSchedulingStrategy",
    "MetricsExporter",
    "ExtensionLoader",
]
