"""用户自定义扩展的扩展接口。

本模块定义了用户扩展必须实现的核心接口，以便与分布式 TTS 系统集成。
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class ExtensionType(Enum):
    """扩展类型枚举。"""
    LOAD_BALANCE_STRATEGY = "load_balance_strategy"
    HEALTH_CHECK_STRATEGY = "health_check_strategy"
    TASK_SCHEDULING_STRATEGY = "task_scheduling_strategy"
    METRICS_EXPORTER = "metrics_exporter"
    EXECUTOR = "executor"


@dataclass
class ExtensionMetadata:
    """扩展元数据。"""
    name: str
    version: str = "1.0.0"
    description: str = ""
    author: str = ""
    extension_type: Optional[ExtensionType] = None
    tags: List[str] = field(default_factory=list)
    config: Dict[str, Any] = field(default_factory=dict)


class Extension(ABC):
    """基础扩展类。"""

    def __init__(self, metadata: ExtensionMetadata):
        self.metadata = metadata
        self._initialized = False

    @abstractmethod
    async def initialize(self) -> None:
        """初始化扩展。"""
        self._initialized = True

    @abstractmethod
    async def cleanup(self) -> None:
        """清理扩展资源。"""
        self._initialized = False

    @property
    def is_initialized(self) -> bool:
        return self._initialized


class LoadBalanceStrategy(ABC):
    """负载均衡策略接口

    用户可实现此接口来创建自定义负载均衡策略。
    """

    @abstractmethod
    async def select_node(
        self,
        available_nodes: List[Any],
        task_context: Optional[Dict[str, Any]] = None,
    ) -> Optional[Any]:
        """从可用节点中选择最佳节点

        参数:
            available_nodes: 可用节点对象列表
            task_context: 可选任务上下文（文本长度、优先级等）

        返回:
            选中的节点对象，若无合适节点则返回 None
        """
        pass

    @abstractmethod
    def get_name(self) -> str:
        """返回策略名称。"""
        pass


class HealthCheckStrategy(ABC):
    """健康检查策略接口

    用户可实现此接口来创建自定义健康检查策略。
    """

    @abstractmethod
    async def check_node_health(self, node: Any) -> bool:
        """检查节点是否健康

        参数:
            node: 要检查的节点对象

        返回:
            节点健康返回 True，否则返回 False
        """
        pass

    @abstractmethod
    def get_name(self) -> str:
        """Return the strategy name"""
        pass


class TaskSchedulingStrategy(ABC):
    """任务调度策略接口

    用户可实现此接口来创建自定义任务调度策略。
    """

    @abstractmethod
    async def schedule_task(
        self,
        task: Any,
        available_nodes: List[Any],
    ) -> Optional[Any]:
        """将任务调度到合适的节点

        参数:
            task: 要调度的任务对象
            available_nodes: 可用节点对象列表

        返回:
            选中的节点对象，若无合适节点则返回 None
        """
        pass

    @abstractmethod
    def get_name(self) -> str:
        """Return the strategy name"""
        pass


class MetricsExporter(ABC):
    """指标导出器接口

    用户可实现此接口来创建自定义指标导出器。
    """

    @abstractmethod
    async def export_metrics(self, metrics_data: Dict[str, Any]) -> bool:
        """导出指标数据

        参数:
            metrics_data: 要导出的指标数据

        返回:
            导出成功返回 True，否则返回 False
        """
        pass

    @abstractmethod
    def get_name(self) -> str:
        """返回导出器名称。"""
        pass
